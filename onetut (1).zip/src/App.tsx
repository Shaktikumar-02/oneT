import React, { useState, useEffect } from "react";
import { 
  Phone, MessageSquare, Compass, ShieldCheck, Star, Users, Award, 
  BookOpen, Sparkles, HelpCircle, ArrowRight, CheckCircle, Brain, 
  MapPin, CheckCircle2, ChevronDown, ChevronUp, Clock, GraduationCap,
  Calendar, Code, Heart, Search, Trophy, Globe, FileText, PhoneCall
} from "lucide-react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import LeadForm from "./components/LeadForm";
import TutorRegistrationForm from "./components/TutorRegistrationForm";
import AIMatchingPanel from "./components/AIMatchingPanel";
import Dashboard from "./components/Dashboard";

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>("home");
  const [selectedCity, setSelectedCity] = useState<string>("Delhi NCR");
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  // Set up Dark Mode / Light Mode class of the document body
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // SEO schemas injection dynamically to fulfill SEO metadata / Schema markup instructions
  useEffect(() => {
    // 1. Meta Title and Description
    document.title = "oneTUT - India's Most Trusted Home Tutor Consultancy";
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute("content", "Find highly qualified, experienced, and verified home tutors and online teachers near you. personal matched tutoring in Delhi, Mumbai, Kolkata, Bengaluru, Pune.");
    } else {
      const meta = document.createElement("meta");
      meta.name = "description";
      meta.content = "Find highly qualified, experienced, and verified home tutors and online teachers near you. personal matched tutoring in Delhi, Mumbai, Kolkata, Bengaluru, Pune.";
      document.head.appendChild(meta);
    }

    // 2. Local Business Schema markup
    const localSchemaId = "onetut-local-schema";
    let localSchemaNode = document.getElementById(localSchemaId);
    if (!localSchemaNode) {
      localSchemaNode = document.createElement("script");
      localSchemaNode.id = localSchemaId;
      localSchemaNode.setAttribute("type", "application/ld+json");
      localSchemaNode.innerHTML = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "EducationalOrganization",
        "name": "oneTUT Home Tutor Consultancy",
        "alternateName": "oneTUT",
        "description": "oneTUT is India's premier professional tuition consultancy platform matching students with verified home tutors and online instructors.",
        "url": "https://onetut.com",
        "logo": "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=100",
        "contactPoint": {
          "@type": "ContactPoint",
          "telephone": "+91-7557758503",
          "contactType": "customer service",
          "areaServed": "IN",
          "availableLanguage": ["English", "Hindi"]
        },
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Kolkata",
          "addressRegion": "West Bengal",
          "addressCountry": "IN"
        }
      });
      document.head.appendChild(localSchemaNode);
    }

    // 3. FAQ Schema
    const faqSchemaId = "onetut-faq-schema";
    let faqSchemaNode = document.getElementById(faqSchemaId);
    if (!faqSchemaNode) {
      faqSchemaNode = document.createElement("script");
      faqSchemaNode.id = faqSchemaId;
      faqSchemaNode.setAttribute("type", "application/ld+json");
      faqSchemaNode.innerHTML = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": faqsData.map(f => ({
          "@type": "Question",
          "name": f.question,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": f.answer
          }
        }))
      });
      document.head.appendChild(faqSchemaNode);
    }

    return () => {
      document.getElementById(localSchemaId)?.remove();
      document.getElementById(faqSchemaId)?.remove();
    };
  }, []);

  const servicesData = [
    {
      title: "Home Tuition",
      desc: "Get an experienced, hand-picked educator right at your doorstep. Safe, convenient, and focused strictly on the student's learning momentum.",
      benefits: ["1-on-1 Dedicated Time", "Comfort of your Home", "Regular Counselor Guidance"],
      popular: true
    },
    {
      title: "Online Tuition",
      desc: "Unrestricted, live interactive virtual classrooms streaming high-definition audio, visual digital whiteboards, and class recordings.",
      benefits: ["Learn from Top National Experts", "Recording features available", "Extremely Flexible timings"],
      popular: false
    },
    {
      title: "Competitive Exam Preparation",
      desc: "Special focus squads for major competitive syllabus targets. Rigorous model tests, fast shortcuts solving, and stress-release mentoring.",
      benefits: ["JEE Mains & Advanced coaching", "NEET Medical Entrance training", "National Olympiads preparation"],
      popular: true
    },
    {
      title: "Skill Development & Spoken English",
      desc: "Unleash speaking confidence, active interview techniques, public presentation mastery, and correct grammar phonetics coaching.",
      benefits: ["Corporate interview preps", "Daily conversation drills", "Voice accent coaching"],
      popular: false
    },
    {
      title: "Coding & Computer Science",
      desc: "Learn algorithmic thinking, web apps foundations, Python scripts, database, and custom AI programming pipelines.",
      benefits: ["Scratch & Python foundations", "Board Computer Science papers", "Interactive games building"],
      popular: false
    }
  ];

  const subjectsData = [
    { name: "Mathematics", icon: "📐", popular: true },
    { name: "Science", icon: "🔬", popular: true },
    { name: "Physics", icon: "⚡", popular: true },
    { name: "Chemistry", icon: "🧪", popular: true },
    { name: "Biology", icon: "🍀", popular: true },
    { name: "English", icon: "📚", popular: false },
    { name: "Hindi", icon: "🖋️", popular: false },
    { name: "Social Science", icon: "🌍", popular: false },
    { name: "Computer Science", icon: "💻", popular: true },
    { name: "Economics", icon: "📈", popular: false },
    { name: "Accountancy", icon: "🧾", popular: false },
    { name: "Business Studies", icon: "🏢", popular: false },
    { name: "Coding", icon: "🚀", popular: true },
    { name: "Programming", icon: "⚙️", popular: false },
    { name: "Artificial Intelligence", icon: "🤖", popular: true }
  ];

  const valueProps = [
    {
      title: "Verified & Trusted Tutors",
      description: "Every teacher goes through rigid ID checks, qualification certificate audits, and historical character screening."
    },
    {
      title: "Highly Qualified & Experienced Faculty",
      description: "Our roster features IIT alumni, Ph.D. holders, postgraduate specialists, school veterans, and retired professors."
    },
    {
      title: "Personalized Learning Flow",
      description: "Zero generic textbook pacing. Tutors modify lesson grids explicitly to fit student grade objectives and focus needs."
    },
    {
      title: "Home Tuition Convenience",
      description: "Save hours spent fighting traffic or commuting. The tutor travels straight to your home on your desired timetable."
    },
    {
      title: "Flexible Class Timetable",
      description: "Set early morning slots, weekend crash workshops, or late-evening homework help based on student availability."
    },
    {
      title: "Regular Academic Progress Tracking",
      description: "Monthly progress cards track key test analytics, vocabulary development, and complete syllabus benchmarks."
    },
    {
      title: "Affordable Pricing Solutions",
      description: "We offer tailored tier selections fitting varying family financial constraints from premium elite to cost-saving options."
    },
    {
      title: "Risk-Free Trial Matching",
      description: "Never settle. Meet your matched tutor in a complimentary 1-hour session. Commit only when 100% satisfied."
    }
  ];

  // Dynamic City wise Featured Tutors Data
  const featuredTutors: { [key: string]: any[] } = {
    "Delhi NCR": [
      {
        name: "Mrs. Shreya Iyer",
        qualification: "M.Sc. in Mathematics (DU)",
        experience: "8 Years",
        subjects: "Maths (Class 9-12), Calculus & Algebra",
        rating: 4.8,
        reviews: 98,
        location: "Vasant Kunj, Delhi",
        avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
        quote: "Making complex calculus graphical and easy."
      },
      {
        name: "CA Manoj Gupta",
        qualification: "Chartered Accountant, B.Com",
        experience: "9 Years",
        subjects: "Accountancy, Economics, Business Studies",
        rating: 4.9,
        reviews: 82,
        location: "Gurugram, NCR",
        avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200",
        quote: "Real world finance stories for accounting students."
      }
    ],
    "Mumbai": [
      {
        name: "Dr. Anjali Deshmukh",
        qualification: "MD in Physiology, M.Sc. Biology",
        experience: "15 Years",
        subjects: "NEET Biology, Zoology, Botany, Science",
        rating: 5.0,
        reviews: 184,
        location: "Andheri West, Mumbai",
        avatar: "https://images.unsplash.com/photo-1594744803329-e58b31de215f?auto=format&fit=crop&q=80&w=200",
        quote: "Scoring high starts with structured diagrammatic memory mapping."
      }
    ],
    "Bengaluru": [
      {
        name: "Prof. Amit Verma",
        qualification: "M.Tech in CS (BITS Pilani)",
        experience: "10+ Years",
        subjects: "Coding, Programming, Python, AI Foundations",
        rating: 4.9,
        reviews: 115,
        location: "Whitefield, Bengaluru",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
        quote: "Code is best learned by building real, playable games."
      }
    ],
    "Kolkata": [
      {
        name: "Dr. Rajesh Mukhopadhyay",
        qualification: "Ph.D. in Physics (IIT Kharagpur)",
        experience: "12+ Years",
        subjects: "JEE Physics, AP Science, Chemistry",
        rating: 4.9,
        reviews: 142,
        location: "Salt Lake, Kolkata",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
        quote: "Mastering physics begins with dismantling the hard mathematical equations."
      }
    ],
    "Pune": [
      {
        name: "Mr. Rohan Saxena",
        qualification: "MA in English Literature",
        experience: "6 Years",
        subjects: "English Lit, Spoken English, Social Prep",
        rating: 4.7,
        reviews: 64,
        location: "Kalyani Nagar, Pune",
        avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200",
        quote: "Fluency isn't about vocabulary size; it's about courage."
      }
    ]
  };

  const testimonials = [
    {
      parent: "Sanjay Singhal (Parent of Class 12 Student)",
      text: "oneTUT was a game changer for my daughter's JEE Physics score. Dr. Rajesh is an extraordinary teacher. He took her from failing mechanics mock exams to scoring 94 percentile. Recommend them 100%!",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?auto=format&fit=crop&q=80&w=100"
    },
    {
      parent: "Ananya Deshpande (Parent of Class 10 Student)",
      text: "Extremely professional tuition service. Finding verified math mentors used to be an offline headache. The counselor matched Mrs. Shreya inside 24 hours, and the free demo session gave us immediate satisfaction.",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100"
    },
    {
      parent: "Dr. K. Raghavan (Competitive Aspirant Parent)",
      text: "The NEET Biology tutor provided solved questions in botany perfectly. My son achieved Air 4200. Verification checks and systematic invoicing make this platform better than individual tution.",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=100"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 dark:bg-slate-900 dark:text-slate-100 font-sans tracking-normal transition-colors duration-300">
      
      {/* Top Banner (ISO Certified / Support Call Out) */}
      <div className="bg-blue-900 text-white text-xs py-2 px-4 font-semibold shrink-0">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-1 sm:space-x-2">
            <span className="bg-amber-500 text-[10px] text-white px-2 py-0.5 rounded-full font-bold uppercase shrink-0">NEW</span>
            <span className="truncate">Active AI Tutor matching with Gemini is now online!</span>
          </div>
          <div className="flex items-center space-x-4 shrink-0">
            <a href="tel:+917557758503" className="flex items-center space-x-1 hover:text-amber-400 transition">
              <Phone className="h-3 w-3" />
              <span className="hidden sm:inline">Support: +91 7557758503</span>
            </a>
          </div>
        </div>
      </div>

      {/* Embedded Navigation Header */}
      <Header 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        darkMode={darkMode} 
        setDarkMode={setDarkMode} 
      />

      {/* MAIN VIEW SYSTEM COMPLIANT WITH TABS */}
      <main className="pb-16">
        
        {currentTab === "home" && (
          <div>
            
            {/* HERO SEGMENT WITH HIGHEST CONVERSION LAYOUT */}
            <section className="relative overflow-hidden bg-gradient-to-b from-blue-50/60 via-white to-slate-50/50 dark:from-slate-950/40 dark:via-slate-900 dark:to-slate-900/50 pt-12 pb-16 lg:py-24 border-b border-slate-100 dark:border-slate-800/20">
              
              <div className="absolute top-0 right-0 h-96 w-96 rounded-full bg-blue-100/30 blur-3xl -z-10 dark:bg-blue-950/10" />
              <div className="absolute bottom-0 left-0 h-96 w-96 rounded-full bg-amber-100/20 blur-3xl -z-10 dark:bg-amber-955/5" />

              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                
                {/* Hero left text block copy */}
                <div className="lg:col-span-7 flex flex-col space-y-6">
                  
                  <div className="inline-flex items-center space-x-2 bg-blue-50 dark:bg-blue-950/30 px-3.5 py-1.5 rounded-full text-blue-700 dark:text-blue-300 font-bold text-xs uppercase tracking-wider max-w-max border border-blue-100/40">
                    <Sparkles className="h-4 w-4 text-amber-500 animate-pulse" />
                    <span>Highly Qualified • Experienced • Verified Teachers</span>
                  </div>

                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white tracking-tight leading-[1.1]">
                    Find the Best <br />
                    <span className="bg-gradient-to-r from-blue-700 via-blue-600 to-amber-600 bg-clip-text text-transparent">Home Tutors</span> Near You
                  </h1>

                  <p className="text-base sm:text-lg text-slate-500 dark:text-slate-400 font-medium leading-relaxed max-w-2xl">
                    oneTUT connects students with trusted, experienced, and result-oriented home tutors and online teachers. Whether you need academic support, exam preparation, or skill development, we match you with the perfect tutor based on your learning goals.
                  </p>

                  {/* Trust Badges Check grid */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-y-3 gap-x-4 pt-2">
                    {[
                      "Verified Tutors Profile",
                      "Full Background Checked",
                      "Experienced Teachers",
                      "Personalized Tutor Match",
                      "Home & Online Tuition"
                    ].map((badge, bIdx) => (
                      <div key={bIdx} className="flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                        <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />
                        <span>{badge}</span>
                      </div>
                    ))}
                  </div>

                  {/* Floating Action CTA links */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 pt-4">
                    <button
                      onClick={() => {
                        const formElem = document.getElementById("hero-lead-form-block");
                        formElem?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="px-6 py-3.5 bg-blue-600 text-white text-sm font-bold rounded-xl shadow-lg shadow-blue-500/10 hover:bg-blue-700 active:scale-95 transition-all text-center"
                    >
                      Find a Tutor
                    </button>
                    <button
                      onClick={() => {
                        setCurrentTab("ai-match");
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      className="px-6 py-3.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-350 border border-slate-200 dark:border-slate-800 text-sm font-bold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 active:scale-95 transition-all flex items-center justify-center space-x-1.5"
                    >
                      <Brain className="h-4 w-4 text-amber-500" />
                      <span>Book Free Consultation</span>
                    </button>
                  </div>

                </div>

                {/* Hero Right Placement Form block (Above Fold Lead form!) */}
                <div className="lg:col-span-5" id="hero-lead-form-block">
                  <LeadForm />
                </div>

              </div>
            </section>

            {/* Numerical statistics counter list */}
            <section className="bg-white dark:bg-slate-850 border-y border-slate-100 dark:border-slate-800/50 py-10 transition-colors">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center" id="live-analytics-counters-grid">
                  {[
                    { val: "5000+", label: "Students Assisted" },
                    { val: "2000+", label: "Verified Tutors" },
                    { val: "100+", label: "Subjects Covered" },
                    { val: "95%", label: "Parent Satisfaction" }
                  ].map((stat, sIdx) => (
                    <div key={sIdx} className="flex flex-col">
                      <span className="text-3xl sm:text-4xl font-black bg-gradient-to-tr from-blue-700 to-amber-500 bg-clip-text text-transparent">
                        {stat.val}
                      </span>
                      <span className="text-xs sm:text-sm text-slate-400 font-bold uppercase tracking-wider mt-1.5">
                        {stat.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* INTERACTIVE GEOGRAPHICAL PILOT LANDING SECTION */}
            <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
              
              <div className="text-center max-w-2xl mx-auto mb-10">
                <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest bg-amber-50 dark:bg-amber-955/20 px-3 py-1 rounded-full border border-amber-100/35">
                  State-Wide Coverage
                </span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-3">Select Your City Hub</h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-md mx-auto">
                  Select a regional core city to instant filter verified home tutors available for immediate democlasses.
                </p>
              </div>

              {/* City pill carousel selector */}
              <div className="flex flex-wrap justify-center gap-2 mb-8">
                {Object.keys(featuredTutors).map((city) => (
                  <button
                    key={city}
                    onClick={() => setSelectedCity(city)}
                    className={`px-5 py-2.5 text-xs font-bold rounded-full transition-all border ${
                      selectedCity === city
                        ? "bg-slate-900 border-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-extrabold shadow-sm"
                        : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    🚀 {city}
                  </button>
                ))}
              </div>

              {/* Featured local tutor carousel container */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="local-tutors-grid">
                {featuredTutors[selectedCity].map((tutor, idx) => (
                  <div 
                    key={idx}
                    className="bg-white dark:bg-slate-850 p-6 border border-slate-100 dark:border-slate-800/80 rounded-3xl shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-5"
                  >
                    <img 
                      src={tutor.avatar} 
                      alt={tutor.name}
                      referrerPolicy="no-referrer"
                      className="h-20 w-20 rounded-2xl object-cover shrink-0 border border-slate-200 dark:border-slate-800"
                    />
                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-black text-slate-900 dark:text-white">{tutor.name}</span>
                        <span className="text-[10px] bg-emerald-50 dark:bg-emerald-955/20 text-emerald-600 dark:text-emerald-400 font-bold px-2 py-0.5 rounded-full">Verified</span>
                      </div>
                      <p className="text-xs text-slate-500 font-medium">{tutor.qualification}</p>
                      
                      <div className="flex flex-wrap gap-1">
                        <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-955/20 px-2 py-0.5 rounded">
                          {tutor.experience} Experience
                        </span>
                        <span className="text-[10px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded leading-relaxed truncate max-w-[200px]">
                          {tutor.subjects}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                        <span className="flex items-center text-amber-500 font-bold text-[11px]">
                          <Star className="h-3.5 w-3.5 fill-amber-500 mr-0.5" />
                          {tutor.rating} ({tutor.reviews} parent reports)
                        </span>
                        <span className="text-[10px] font-medium text-slate-400">📍 {tutor.location}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* CRM Lead booster matching call-to-action bar */}
              <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-amber-600 p-6 sm:p-10 rounded-3xl text-center text-white mt-12 grid grid-cols-1 md:grid-cols-4 gap-6 items-center shadow-lg">
                <div className="md:col-span-3 text-center md:text-left space-y-2">
                  <h4 className="text-xl sm:text-2xl font-black">Get matched with tutors inside 1 hour in {selectedCity}</h4>
                  <p className="text-xs sm:text-sm text-blue-50 font-medium">
                    Submit your details and get customized recommendation list detailing qualification match scores.
                  </p>
                </div>
                <button
                  onClick={() => {
                    const viewElem = document.getElementById("hero-lead-form-block");
                    viewElem?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="px-6 py-3.5 bg-slate-900 border border-slate-850 hover:bg-slate-950 text-white font-bold text-xs rounded-xl uppercase tracking-wider shadow-md active:scale-95 transition"
                >
                  Match with {selectedCity} Tutor
                </button>
              </div>

            </section>

            {/* SERVICES SECTION */}
            <section className="bg-slate-100/50 dark:bg-slate-950/20 py-20 border-y border-slate-100 dark:border-slate-800/30">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                
                <div className="text-center max-w-2xl mx-auto mb-16">
                  <span className="text-xs font-bold text-blue-700 dark:text-blue-400 uppercase tracking-widest bg-blue-50 dark:bg-blue-955/35 px-3 py-1 rounded-full border border-blue-100/35">
                    Premium Frameworks
                  </span>
                  <h3 className="text-3xl font-black text-slate-900 dark:text-white mt-3">Personalized Services</h3>
                  <p className="text-sm font-medium text-slate-500 mt-2">
                    Whether you require structured home sessions or fluid digital whiteboards, our consultancy covers vital educational formats.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {servicesData.map((ser, sIdx) => (
                    <div 
                      key={sIdx}
                      className="bg-white dark:bg-slate-855 border border-slate-100 dark:border-slate-805 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <div className="h-10 w-10 text-xs font-bold flex items-center justify-center rounded-lg bg-blue-100 text-blue-700 dark:bg-blue-950/25 dark:text-blue-300">
                            0{sIdx + 1}
                          </div>
                          {ser.popular && (
                            <span className="bg-amber-500 text-white font-bold text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                              In High Demand
                            </span>
                          )}
                        </div>

                        <h4 className="text-lg font-bold text-slate-900 dark:text-white">{ser.title}</h4>
                        <p className="text-xs text-slate-500 leading-relaxed">{ser.desc}</p>
                      </div>

                      <div className="mt-6 pt-4 border-t border-slate-50 dark:border-slate-800/50">
                        <ul className="space-y-1.5">
                          {ser.benefits.map((b, bIdx) => (
                            <li key={bIdx} className="text-xs font-semibold text-slate-700 dark:text-slate-350 flex items-center space-x-1.5">
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                              <span>{b}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            </section>

            {/* SYSTEM HOW IT WORKS PROCESS TIMELINE */}
            <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
              
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest bg-amber-50 dark:bg-amber-955/20 px-3 py-1 rounded-full border border-amber-100/35">
                  Strategic Onboarding
                </span>
                <h3 className="text-3xl font-black text-slate-900 dark:text-white mt-3">How it works</h3>
                <p className="text-sm font-medium text-slate-500 mt-2">
                  Our transparent 5-step counselor process guarantees flawless matches without academic compromise.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-6 relative" id="how-it-works-timeline">
                
                {/* Visual horizontal guide divider line on desktop */}
                <div className="hidden md:block absolute top-12 left-12 right-12 h-0.5 bg-slate-100 -z-10" />

                {[
                  { step: "Step 1", title: "Submit Requirement", desc: "Fill out the consultation form with class, subject, and goals." },
                  { step: "Step 2", title: "Counselor Call", desc: "Our tuition manager calls you to map specific needs & budget." },
                  { step: "Step 3", title: "Tutor Matching", desc: "We coordinate with vetted educators to analyze qualifications." },
                  { step: "Step 4", title: "Free Demo Session", desc: "Evaluate your matched tutor in a risk-free sample class." },
                  { step: "Step 5", title: "Start Learning", desc: "Finalize your schedules and start regular 1-on-1 development." }
                ].map((item, idx) => (
                  <div key={idx} className="bg-white dark:bg-slate-850 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col items-center text-center relative z-10 hover:border-blue-300 dark:hover:border-blue-900 transition-all duration-300">
                    <div className="h-10 w-10 flex items-center justify-center rounded-full bg-blue-600 text-white font-extrabold text-sm shadow-md mb-4">
                      {idx + 1}
                    </div>
                    <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-wider">{item.step}</span>
                    <h5 className="text-sm font-extrabold text-slate-850 dark:text-white mt-1">{item.title}</h5>
                    <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>

            </section>

            {/* VALUE PROPOSITIONS SECTION */}
            <section className="bg-slate-900 text-white py-20 border-t border-slate-800">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                
                <div className="text-center max-w-2xl mx-auto mb-16">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    Operational Integrity
                  </span>
                  <h3 className="text-3xl font-black text-white mt-4">Why Parents Choose oneTUT</h3>
                  <p className="text-sm font-medium text-slate-400 mt-2">
                    Designed as an elite alternative to local unorganized tuition channels, ensuring safety and regular progress tracing.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {valueProps.map((prop, idx) => (
                    <div 
                      key={idx} 
                      className="bg-slate-950/45 p-6 rounded-2xl border border-slate-800 space-y-2.5 hover:border-amber-500/30 transition duration-300"
                    >
                      <div className="h-8 w-8 text-xs font-bold flex items-center justify-center rounded bg-amber-500/10 text-amber-500">
                        ✓
                      </div>
                      <h4 className="text-sm font-bold text-white">{prop.title}</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">{prop.description}</p>
                    </div>
                  ))}
                </div>

              </div>
            </section>

            {/* SUBJECTS INTERACTIVE SELECTION GRID */}
            <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8" id="subjects">
              
              <div className="text-center max-w-2xl mx-auto mb-12">
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest bg-blue-50 dark:bg-blue-955/20 px-3 py-1 rounded-full border border-blue-100/35">
                  Scope of Expertise
                </span>
                <h3 className="text-3xl font-black text-slate-900 dark:text-white mt-3">15+ Core Subjects Covered</h3>
                <p className="text-sm font-medium text-slate-500 mt-2">
                  Click on any subject pill to match with specialized home tutors instantly.
                </p>
              </div>

              <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
                {subjectsData.map((sub, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      const element = document.getElementById("hero-lead-form-block");
                      element?.scrollIntoView({ behavior: "smooth" });
                      // We can pass or let them fill in
                    }}
                    className="flex items-center space-x-2 px-5 py-3 bg-white dark:bg-slate-850 hover:bg-slate-100 border border-slate-200 dark:border-slate-805 text-sm font-semibold text-slate-700 dark:text-slate-350 hover:scale-105 active:scale-95 transition-all rounded-2xl shadow-sm"
                  >
                    <span>{sub.icon}</span>
                    <span>{sub.name}</span>
                    {sub.popular && (
                      <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse ml-1" />
                    )}
                  </button>
                ))}
              </div>

            </section>

            {/* TESTIMONIALS SLIDER SECTION */}
            <section className="bg-slate-100/50 dark:bg-slate-950/20 py-20 border-y border-slate-100 dark:border-slate-800/30">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                
                <div className="text-center max-w-2xl mx-auto mb-16">
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest bg-amber-50 dark:bg-amber-955/20 px-3 py-1 rounded-full border border-amber-100/35">
                    Parent Reports
                  </span>
                  <h3 className="text-3xl font-black text-slate-900 dark:text-white mt-3">What parents are saying</h3>
                  <p className="text-sm font-medium text-slate-500 mt-2">
                    Verified ratings shared by families across India reflecting continuous academic growth.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {testimonials.map((test, index) => (
                    <div key={index} className="bg-white dark:bg-slate-855 p-6 border border-slate-100 dark:border-slate-805 rounded-3xl shadow-sm flex flex-col justify-between">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-1 text-amber-400">
                          {[...Array(test.rating)].map((_, rIdx) => (
                            <Star key={rIdx} className="h-4 w-4 fill-amber-400 text-amber-400" />
                          ))}
                        </div>
                        <p className="text-xs italic text-slate-500 leading-relaxed">
                          "{test.text}"
                        </p>
                      </div>

                      <div className="flex items-center space-x-3.5 pt-6 border-t border-slate-50 dark:border-slate-800/40 mt-6">
                        <img 
                          src={test.avatar} 
                          alt={test.parent}
                          referrerPolicy="no-referrer"
                          className="h-9 w-9 rounded-full object-cover border border-slate-205/50"
                        />
                        <span className="text-xs font-extrabold text-slate-800 dark:text-slate-300">
                          {test.parent}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            </section>

          </div>
        )}

        {currentTab === "services" && (
          <div className="mx-auto max-w-5xl px-4 py-12">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white text-center">Our Consultancy Formats</h2>
            <p className="text-sm text-slate-500 text-center max-w-md mx-auto mt-2">
              Browse customized tuition alignments built to unlock student scores. Click "Find a Tutor" to establish contact channels!
            </p>

            <div className="space-y-12 mt-12">
              {servicesData.map((ser, index) => (
                <div key={index} className="bg-white dark:bg-slate-850 p-6 sm:p-10 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
                  <div className="md:col-span-2 space-y-4">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-600 bg-amber-50 dark:bg-amber-955/20 px-2.5 py-0.5 rounded-full">Format 0{index + 1}</span>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">{ser.title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{ser.desc}</p>
                    
                    <div className="flex flex-wrap gap-2 pt-2">
                      {ser.benefits.map((b, bIdx) => (
                        <span key={bIdx} className="text-xs bg-slate-50 dark:bg-slate-900 text-slate-650 px-2.5 py-1 rounded-xl font-medium border border-slate-150/45 whitespace-nowrap">
                          ✓ {b}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-2xl text-center space-y-4 border border-slate-150/45 col-span-1">
                    <span className="text-xs text-slate-400 font-bold uppercase">Estimated rate</span>
                    <h4 className="text-xl font-extrabold text-blue-600">₹600 - ₹1200 / hr</h4>
                    <button
                      onClick={() => {
                        const elem = document.getElementById("hero-lead-form-block");
                        setCurrentTab("home");
                        setTimeout(() => elem?.scrollIntoView({ behavior: "smooth" }), 200);
                      }}
                      className="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 transition"
                    >
                      Instant Inquiry Matching
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentTab === "subjects" && (
          <div className="mx-auto max-w-4xl px-4 py-12">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white text-center">Comprehensive Subjects roster</h2>
            <p className="text-sm text-slate-500 text-center max-w-md mx-auto mt-2 mb-12">
              Every subject represents certified home teachers ready for direct 1-on-1 demo scheduling.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {subjectsData.map((sub, idx) => (
                <div key={idx} className="bg-white dark:bg-slate-850 p-6 border border-slate-100 rounded-3xl text-center shadow-sm hover:border-blue-500/30 transition">
                  <span className="text-3xl">{sub.icon}</span>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-3">{sub.name}</h4>
                  <p className="text-[10px] text-slate-401 mt-1 font-semibold text-slate-400">Class 1 to Class 12 Boards</p>
                  <button
                    onClick={() => {
                      setCurrentTab("home");
                      setTimeout(() => {
                        document.getElementById("hero-lead-form-block")?.scrollIntoView({ behavior: "smooth" });
                      }, 200);
                    }}
                    className="mt-4 text-[11px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/20 px-3 py-1.5 rounded-lg transition hover:bg-blue-100"
                  >
                    Select Subject
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentTab === "why-us" && (
          <div className="mx-auto max-w-5xl px-4 py-12 space-y-12">
            
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <h2 className="text-3xl font-black text-slate-900 dark:text-white">Why leading schools & parents recommend oneTUT</h2>
              <p className="text-sm text-slate-500">
                A system built from the ground up to replace unreliable freelance tutors with a cohesive professional network.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {valueProps.map((prop, idx) => (
                <div key={idx} className="bg-white dark:bg-slate-850 border border-slate-100 dark:border-slate-805/45 p-6 rounded-3xl flex items-start space-x-4 shadow-sm hover:translate-y-[-2px] transition-all duration-300">
                  <div className="p-2.5 bg-blue-50 dark:bg-blue-955/20 text-blue-600 rounded-xl font-bold text-sm shrink-0">
                    🏆
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-base font-bold text-slate-900 dark:text-white">{prop.title}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">{prop.description}</p>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {currentTab === "tutors" && (
          <div className="mx-auto max-w-5xl px-4 py-12">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white text-center">Meet Our Premium Verified Tutors</h2>
            <p className="text-sm text-slate-500 text-center max-w-md mx-auto mt-2">
              Every educator has validated academic certificates, verified history audits, and excellent test prep metrics.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
              {Object.values(featuredTutors).flat().map((tutor, idx) => (
                <div key={idx} className="bg-white dark:bg-slate-850 p-6 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-5">
                  <img src={tutor.avatar} alt={tutor.name} referrerPolicy="no-referrer" className="h-20 w-20 rounded-2xl object-cover border border-slate-200 dark:border-slate-800" />
                  <div className="flex-1 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-base font-bold text-slate-900 dark:text-white">{tutor.name}</span>
                      <span className="text-[9px] font-black uppercase tracking-wider text-green-600 bg-green-50 dark:bg-green-950/20 px-2.5 py-0.5 rounded-full border border-green-200/50">Verified</span>
                    </div>
                    <p className="text-xs text-slate-500 font-medium">{tutor.qualification}</p>
                    <p className="text-xs text-slate-400 font-bold">🏫 {tutor.experience} Teaching Experience</p>
                    <p className="text-xs text-slate-655 font-medium italic text-slate-500">"{tutor.quote}"</p>
                    
                    <div className="mt-3 flex items-center justify-between text-xs pt-1 border-t border-slate-50 dark:border-slate-800/10">
                      <span className="flex items-center text-amber-500 font-bold">
                        <Star className="h-3.5 w-3.5 fill-amber-500 mr-0.5" />
                        {tutor.rating}
                      </span>
                      <span className="text-[10px] text-slate-400">📍 {tutor.location}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentTab === "become-tutor" && (
          <div className="mx-auto max-w-4xl px-4 py-12">
            <TutorRegistrationForm />
          </div>
        )}

        {currentTab === "ai-match" && (
          <div className="mx-auto max-w-7xl">
            <AIMatchingPanel />
          </div>
        )}

        {currentTab === "admin" && (
          <div className="mx-auto max-w-7xl">
            <Dashboard />
          </div>
        )}

        {/* 15 Collapsible FAQs Section */}
        {currentTab === "faq" && (
          <div className="mx-auto max-w-3xl px-4 py-12 space-y-8" id="faqs-block-section">
            
            <div className="text-center space-y-2">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100 text-amber-600">
                <HelpCircle className="h-5 w-5" />
              </span>
              <h2 className="text-3xl font-black text-rose-955 text-slate-900 dark:text-white mt-2">Browse 15 Frequently Asked Questions</h2>
              <p className="text-sm text-slate-500">
                Everything you need to know about pricing models, tutor verification protocols, demo classes, and custom board syllabuses.
              </p>
            </div>

            <div className="space-y-4">
              {faqsData.map((faq, idx) => (
                <div 
                  key={idx} 
                  className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-805 shadow-sm overflow-hidden"
                >
                  <button
                    onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                    className="w-full p-5 text-left font-bold text-slate-800 dark:text-slate-300 text-sm flex justify-between items-center hover:bg-slate-50 transition"
                  >
                    <span>{idx + 1}. {faq.question}</span>
                    {activeFaq === idx ? (
                      <ChevronUp className="h-4 w-4 text-blue-600" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-slate-400" />
                    )}
                  </button>

                  {activeFaq === idx && (
                    <div className="p-5 border-t border-slate-100 dark:border-slate-800 text-xs leading-relaxed text-slate-500 dark:text-slate-400 font-medium">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>

          </div>
        )}

      </main>

      {/* FLOATING WHATSAPP BUTTON (ON EVERY PAGE!) WITH REQUIRED LABEL */}
      <a
        href="https://wa.me/917557758503?text=Greetings%20from%20oneTUT.%20We%20will%20connect%20you%20with%20a%20tutor%20soon.%20Kindly%20allow%20us%20some%20time."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 flex items-center space-x-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs px-3 sm:px-4 py-3 rounded-full shadow-lg hover:shadow-emerald-500/20 active:scale-95 transition-all text-center shrink-0"
        id="floating-whatsapp-trigger"
      >
        <MessageSquare className="h-5.5 w-5.5 text-white animate-bounce-slow" />
        <span className="hidden sm:inline">Need a Tutor? Chat Now</span>
      </a>

      {/* Corporate structured Footer */}
      <Footer setCurrentTab={setCurrentTab} />

    </div>
  );
}

// 15 Structured Professional FAQs covering comprehensive tuition details
const faqsData = [
  {
    question: "What makes oneTUT different from choosing individual freelance tutors?",
    answer: "oneTUT acts as an enterprise-level regulatory body. Choose us over unorganized channels because we audit educational certificates, execute double-source background verify checks, provide replacement guarantees if dissatisfied, and share structured monthly reports detailing academic performance."
  },
  {
    question: "How do you verify your tutors' academic records and backgrounds?",
    answer: "We perform strict qualification certification reviews (validating original graduation/postgraduate papers) along with identity checks (Government of India Aadhar and PAN cards). For premium staff, we check past educational center feedback before granting certified tutor privileges."
  },
  {
    question: "Do you offer a completely free trial/demo session?",
    answer: "Yes! Every single matched tutor suggestion comes with a complimentary 1-hour home or online demo class. You can interact, learn, and evaluate the teacher's style risk-free. Pay only when you are 100% satisfied and commit to monthly pacing."
  },
  {
    question: "What are the average pricing guides for home or online tuition?",
    answer: "Our standard pricing averages from ₹600 to ₹1200 hourly depending on grade requirements (primary vs competition JEE/NEET prep), regional location proximity, and teacher qualifications (postgraduate vs senior Ph.D. veterans)."
  },
  {
    question: "Do you cover IIT JEE Mains and NEET medical preparations?",
    answer: "Yes, competitive prep is our specialty. We provide seasoned subject masters who are alumni of top educational institutes (such as IITs and medical universities) who understand target paper structures, short formula solving, and Mock analytics."
  },
  {
    question: "Can I replace my assigned tutor if the learning pace is not satisfatory?",
    answer: "Absolutely. Student-teacher chemistry is crucial. If at any moment the parent or student feels dissatisfied with progress, contact our educational counselor and we will assign a qualified replacement immediately at no secondary charge."
  },
  {
    question: "What tracking metrics are provided for parent reporting?",
    answer: "We share structured monthly progress cards. This counselor sheet includes vocabulary tracking, concept mastery ratings across physical science & algebra, model test scores, homework accuracy logs, and future class scheduling pipelines."
  },
  {
    question: "Are online classes distinct from traditional home sessions?",
    answer: "Our online sessions replicate home quality using high-definition interactive class software, digital whiteboards, real-time shared quizzes, block diagrams, and mandatory access to recorded classes for continuous reference."
  },
  {
    question: "Do you cover Class 1 to 12 CBSE, ICSE, and Indian State Boards?",
    answer: "Yes, our certified teachers are specialized in multiple curriculum guidelines including CBSE, CISCE (ICSE/ISC), state boards, IB, and Cambridge layouts."
  },
  {
    question: "How quickly will you coordinate a tutor once I submit the requirement form?",
    answer: "Once we capture details via the website, our counselor schedules a validation call inside 30 minutes. We filter appropriate profiles and match available local educators to start your complimentary demo within 24 to 48 hours."
  },
  {
    question: "Are textbook study materials included in the coaching plans?",
    answer: "Tutors provide core revision mock notes, formula reference booklets, conceptual summaries, and board question banks. General school textbook procurement remains with the parents."
  },
  {
    question: "What scope of subjects can I get matched with?",
    answer: "We cover Mathematics (Arithmetic, Advanced Calculus), Physics, Chemistry, Biology (Botany & Zoology), Computer Sc / Programming (Python, Web apps, AI), English Literature, spoken English fluency, Social Prep, Accountancy, Economics, and Business Studies."
  },
  {
    question: "Can college students apply for teaching roles under oneTUT?",
    answer: "We only approve college candidates with outstanding records (e.g. topper in target board or outstanding college CGPA) who pass our mock tutoring test. Preference is given to postgraduate teachers or professional professors."
  },
  {
    question: "How do parents verify physical details before admitting a home tutor?",
    answer: "Your matched demo assignment alert notification includes detailed credential specs: teacher degree photos, past score history, government identity verification tokens, and counselor certification guarantees."
  },
  {
    question: "Is there a safety policy for home tutoring support?",
    answer: "Student safety is our highest priority at oneTUT. All tutors complete detailed background screenings. In addition, our tuition counselors stay in regular lock-step communication with families after lessons to guarantee absolute physical decorum."
  }
];
