export interface Lead {
  leadId: string;
  name: string;
  mobileNumber: string;
  city: string;
  class: string;
  subject: string;
  tuitionType: 'Home Tuition' | 'Online Tuition';
  timestamp: string;
  source: string;
  status: 'New Lead' | 'In Contact' | 'Matched' | 'Converted' | 'Rejected';
}

export interface Tutor {
  tutorId: string;
  name: string;
  mobileNumber: string;
  email: string;
  qualification: string;
  experience: string;
  subjectExpertise: string;
  resume?: string;
  timestamp: string;
  status: 'Pending Review' | 'Approved' | 'Rejected';
}

export interface Review {
  reviewId: string;
  studentName: string;
  parentName?: string;
  rating: number; // 1-5
  text: string;
  class?: string;
  subject?: string;
  date: string;
}

export interface BlogPost {
  blogId: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
}
