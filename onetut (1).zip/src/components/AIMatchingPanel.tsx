import React, { useState } from "react";
import { Sparkles, Loader2, Star, ShieldCheck, MapPin, Compass, PhoneCall, Calendar, MessageSquare, Brain } from "lucide-react";

export default function AIMatchingPanel() {
  const [inputs, setInputs] = useState({
    className: "Class 10",
    subject: "Mathematics",
    city: "Delhi NCR",
    tuitionType: "Home Tuition",
    requirements: "",
  });

  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [matches, setMatches] = useState<any[]>([]);
  const [errorMsg, setErrorMsg] = useState("");
  const [success, setSuccess] = useState(false);
  const [selectedTutor, setSelectedTutor] = useState<any>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const majorSubjects = [
    "Mathematics", "Physics", "Chemistry", "Biology", "English",
    "Social Science", "Computer Science", "Economics", "Accountancy", "Coding", "Artificial Intelligence"
  ];

  const classList = [
    "Class 1 - 5", "Class 6 - 8", "Class 9", "Class 10", "Class 11", "Class 12", "JEE Preparation", "NEET Preparation", "Coding"
  ];

  const loadingPhrases = [
    "Initializing Gemini AI Matchmaking Engine...",
    "Retrieving available certified tutors list...",
    "Filtering for subject background & credentials...",
    "Analyzing location geographic grid alignment...",
    "Computing optimal match compatibility matrix...",
    "Structuring premium tutor recommendations..."
  ];

  const triggerAIMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");
    setMatches([]);
    setSuccess(false);

    // Dynamic Loading Step Animation
    let curStep = 0;
    const interval = setInterval(() => {
      curStep = (curStep + 1) % loadingPhrases.length;
      setLoadingStep(curStep);
    }, 1200);

    try {
      const response = await fetch("/api/ai/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inputs),
      });

      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || "Failed to parse AI Recommendations.");
      }

      setMatches(resData.matches || []);
      setSuccess(true);
    } catch (err: any) {
      setErrorMsg(err.message || "An error occurred while matching. Please try again.");
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  const handleBookDemo = (tutor: any) => {
    setSelectedTutor(tutor);
    setBookingSuccess(false);
  };

  const finalizeDemoBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSuccess(true);
    // Simulate real database lead capture for demo
    setTimeout(() => {
      setSelectedTutor(null);
      setBookingSuccess(false);
    }, 4500);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      
      {/* Header and summary */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center space-x-1 px-3 py-1 bg-white/5 rounded-full border border-white/10 mb-3 text-xs font-semibold text-slate-300">
          <Brain className="h-4 w-4 text-[#D4AF37] animate-pulse" />
          <span>Equipped with Gemini 3.5-flash Advanced Analytics</span>
        </div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white font-display">AI-Powered Premium Tutor Match</h2>
        <p className="text-sm font-medium text-slate-400 mt-2">
          State your child's academic grade level, focus subjects, learning gaps, and requirements. Our AI assistant will analyze real-time teacher qualifications and select the perfect top 3 educators instantly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Input Form Panel */}
        <div className="lg:col-span-5 bg-white/5 p-6 rounded-3xl border border-white/10 shadow-2xl backdrop-blur-md">
          <h3 className="text-base font-bold text-white font-display mb-4 flex items-center space-x-2">
            <Compass className="h-5 w-5 text-[#D4AF37]" />
            <span>Describe Student Goals</span>
          </h3>

          <form onSubmit={triggerAIMatch} className="space-y-4">
            
            {/* Class grade level */}
            <div className="flex flex-col space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Student Class/Grade</label>
              <select
                value={inputs.className}
                onChange={(e) => setInputs({ ...inputs, className: e.target.value })}
                className="px-4 py-2 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
              >
                {classList.map((cl) => (
                  <option key={cl} value={cl} className="bg-[#050B16] text-slate-200">{cl}</option>
                ))}
              </select>
            </div>

            {/* Subject Dropdown */}
            <div className="flex flex-col space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Core Focus Subject</label>
              <select
                value={inputs.subject}
                onChange={(e) => setInputs({ ...inputs, subject: e.target.value })}
                className="px-4 py-2 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
              >
                {majorSubjects.map((sub) => (
                  <option key={sub} value={sub} className="bg-[#050B16] text-slate-200">{sub}</option>
                ))}
              </select>
            </div>

            {/* Geographical City */}
            <div className="flex flex-col space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Preferred City</label>
              <select
                value={inputs.city}
                onChange={(e) => setInputs({ ...inputs, city: e.target.value })}
                className="px-4 py-2 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
              >
                <option value="Delhi NCR" className="bg-[#050B16] text-slate-200">Delhi NCR</option>
                <option value="Mumbai" className="bg-[#050B16] text-slate-200">Mumbai</option>
                <option value="Bengaluru" className="bg-[#050B16] text-slate-200">Bengaluru</option>
                <option value="Kolkata" className="bg-[#050B16] text-slate-200">Kolkata</option>
                <option value="Pune" className="bg-[#050B16] text-slate-200">Pune</option>
              </select>
            </div>

            {/* Tuition Type */}
            <div className="flex flex-col space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Select Mode</label>
              <div className="grid grid-cols-2 gap-3">
                {["Home Tuition", "Online Tuition"].map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setInputs({ ...inputs, tuitionType: mode })}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border transition ${
                      inputs.tuitionType === mode
                        ? "border-[#D4AF37] bg-white/5 text-[#D4AF37] font-black"
                        : "border-white/10 text-slate-400 bg-[#0A1324] hover:bg-white/5"
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Special Context (Tutor requirements) */}
            <div className="flex flex-col space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Special Requirements (Optional)</label>
              <textarea
                value={inputs.requirements}
                maxLength={400}
                onChange={(e) => setInputs({ ...inputs, requirements: e.target.value })}
                placeholder="E.g., struggling with organic chemistry reactions, needs a tutor available on weekends to prepare for Board exams..."
                className="px-4 py-2 h-24 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition resize-none"
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 text-xs font-bold text-white bg-[#0077FF] hover:bg-[#0066DD] hover:shadow-[0_0_20px_rgba(0,119,255,0.4)] transition-all uppercase tracking-widest rounded-xl flex items-center justify-center space-x-2 cursor-pointer"
              id="ai-matching-trigger-btn"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin text-white" />
                  <span>Matching...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 text-white" />
                  <span>Find Matches with AI</span>
                </>
              )}
            </button>

          </form>
        </div>

        {/* Right Output Results Panel */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Initial Blank State */}
          {!loading && !success && (
            <div className="flex flex-col items-center justify-center text-center p-12 bg-white/5 border-2 border-dashed border-white/10 rounded-3xl h-full min-h-[400px]">
              <div className="h-12 w-12 rounded-2xl bg-white/5 flex items-center justify-center text-[#D4AF37] mb-4 animate-pulse">
                <Brain className="h-6 w-6" />
              </div>
              <h4 className="text-lg font-bold text-white">Awaiting Requirements</h4>
              <p className="text-xs text-slate-400 max-w-sm mt-1.5 font-medium">
                Submit the requirement form on the left to activate our real-time matching system. Results include expert analysis, match scores, and specific learning path proposals.
              </p>
            </div>
          )}

          {/* Loading state with dynamic subtitles */}
          {loading && (
            <div className="flex flex-col items-center justify-center text-center p-12 bg-white/5 rounded-3xl shadow-2xl h-full min-h-[400px] border border-white/10 animate-pulse">
              <div className="relative">
                <div className="h-20 w-20 rounded-full border-4 border-white/5 border-t-[#D4AF37] animate-spin" />
                <Brain className="absolute top-6 left-6 h-8 w-8 text-[#0077FF] animate-bounce" />
              </div>
              <h4 className="text-lg font-bold text-white mt-6 font-display">Consulting AI Matching Protocol</h4>
              <p className="text-xs text-[#D4AF37] font-bold mt-2 animate-pulse uppercase tracking-wider">
                {loadingPhrases[loadingStep]}
              </p>
              <p className="text-xs text-slate-400 max-w-xs mt-3 leading-relaxed">
                Our algorithm checks teacher availability, background checks, subject match density, and former student reviews.
              </p>
            </div>
          )}

          {/* Error fallback */}
          {errorMsg && (
            <div className="p-6 bg-red-50 border border-red-200 text-red-600 rounded-2xl text-sm">
              {errorMsg}
            </div>
          )}

          {/* Successfully matched list */}
          {success && matches.length > 0 && (
            <div className="space-y-6 animate-fade-in" id="ai-matches-container">
              <h3 className="text-lg font-extrabold text-white font-display flex items-center space-x-2">
                <ShieldCheck className="h-5.5 w-5.5 text-emerald-400" />
                <span>We Found {matches.length} Verified Ideal Matches!</span>
              </h3>

              {matches.map((match, idx) => {
                const tutor = match.tutorInfo;
                return (
                  <div 
                    key={idx}
                    className="bg-white/5 border border-white/10 rounded-3xl p-6 shadow-2xl hover:border-[#D4AF37]/30 transition-all relative overflow-hidden group"
                  >
                    
                    {/* Glass Match Badge */}
                    <div className="absolute top-0 right-0 bg-[#0077FF] px-4 py-2 text-xs font-black text-white rounded-bl-2xl flex items-center space-x-1 shadow-md">
                      <Sparkles className="h-3 w-3 text-white" />
                      <span>{match.matchPercentage}% AI Fit</span>
                    </div>

                    <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-5">
                      {/* Avatar */}
                      <img 
                        src={tutor.avatar || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200"}
                        alt={tutor.name}
                        referrerPolicy="no-referrer"
                        className="h-16 w-16 rounded-xl object-cover shrink-0 border border-white/10"
                      />

                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="text-base font-bold text-white font-display group-hover:text-[#D4AF37] transition">
                            {tutor.name}
                          </h4>
                          {tutor.starred && (
                            <div className="flex items-center bg-white/5 text-[#D4AF37] border border-[#D4AF37]/35 text-[9px] px-1.5 py-0.5 rounded-full font-bold">
                              Top Rated
                            </div>
                          )}
                        </div>

                        <p className="text-xs text-slate-400 font-medium">{tutor.qualification}</p>
                        
                        <div className="flex items-center space-x-3 text-xs text-slate-450 mt-1">
                          <span className="flex items-center text-[#D4AF37] font-bold">
                            <Star className="h-3 w-3 fill-[#D4AF37] mr-1 text-[#D4AF37]" />
                            {tutor.rating || "4.8"} ({tutor.reviewsCount || "80+"} reviews)
                          </span>
                          <span>•</span>
                          <span className="flex items-center text-slate-400">
                            <MapPin className="h-3 w-3 text-slate-400 mr-0.5" />
                            {tutor.location}
                          </span>
                          <span>•</span>
                          <span className="font-semibold text-emerald-400">{tutor.experience} Experience</span>
                        </div>
                      </div>
                    </div>

                    {/* Fit analysis */}
                    <div className="mt-4 bg-[#0A1324] border border-white/10 p-4 rounded-2xl">
                      <h5 className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider flex items-center space-x-1">
                        <Star className="h-3.5 w-3.5 text-[#D4AF37] fill-[#D4AF37]" />
                        <span>AI Structural Suitability Analysis</span>
                      </h5>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        {match.fitAnalysis}
                      </p>
                    </div>

                    {/* Recommendations bullet */}
                    {match.recommendations && match.recommendations.length > 0 && (
                      <div className="mt-3.5 pt-3.5 border-t border-white/10">
                        <h6 className="text-[11px] font-bold text-slate-450 uppercase tracking-wider">Proposed Counseling Strategy:</h6>
                        <ul className="mt-1.5 space-y-1">
                          {match.recommendations.map((rec: string, rIdx: number) => (
                            <li key={rIdx} className="text-xs text-slate-400 flex items-start space-x-1.5">
                              <span className="text-[#D4AF37] mt-0.5 font-bold">•</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Match Action buttons */}
                    <div className="mt-5 flex items-center space-x-3">
                      <button
                        onClick={() => handleBookDemo(tutor)}
                        className="flex-1 py-3 text-xs font-bold text-white bg-[#0077FF] hover:bg-[#0066DD] hover:shadow-[0_0_15px_rgba(0,119,255,0.3)] rounded-xl transition cursor-pointer flex items-center justify-center space-x-1.5"
                      >
                        <Calendar className="h-4 w-4 text-white" />
                        <span>Book Demo with {tutor.name.split(" ")[1] || "Tutor"}</span>
                      </button>

                      <a
                        href="tel:+917557758503"
                        className="px-3 py-3 text-xs font-bold text-slate-200 border border-white/10 hover:bg-white/5 rounded-xl transition flex items-center space-x-1"
                      >
                        <PhoneCall className="h-3.5 w-3.5 text-[#D4AF37]" />
                        <span className="hidden sm:inline">Call Consultancy</span>
                      </a>
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>

      {/* Book Demo Modal Overlay */}
      {selectedTutor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#050B16]/80 backdrop-blur-md p-4">
          <div className="bg-[#0A1324] border border-white/10 max-w-md w-full rounded-3xl p-6 shadow-2xl space-y-4">
            
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-lg font-bold text-white font-display">Register Free Demo Class</h4>
                <p className="text-xs text-slate-400">Scheduling introductory class with {selectedTutor.name}</p>
              </div>
              <button 
                onClick={() => setSelectedTutor(null)}
                className="p-1 px-2.5 bg-white/5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition duration-200 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {bookingSuccess ? (
              <div className="p-8 text-center bg-emerald-950/40 text-emerald-300 rounded-2xl border border-emerald-900/50">
                <span className="text-xl font-bold font-display">Booking Confirmed!</span>
                <p className="text-xs mt-2 text-slate-300">We have locked in a pre-demo slot with {selectedTutor.name}. Our counseling team will text you on WhatsApp within 30 minutes to specify timetables.</p>
              </div>
            ) : (
              <form onSubmit={finalizeDemoBooking} className="space-y-4">
                <div className="flex flex-col space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Student Contact Name</label>
                  <input type="text" required placeholder="E.g., Sanjay Shah" className="px-3 py-2.5 text-sm border border-white/10 rounded-xl bg-[#050B16] text-white focus:outline-none focus:border-[#D4AF37]" />
                </div>
                <div className="flex flex-col space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Parent Mobile Number</label>
                  <input type="tel" required placeholder="10-digit mobile phone" className="px-3 py-2.5 text-sm border border-white/10 rounded-xl bg-[#050B16] text-white focus:outline-none focus:border-[#D4AF37]" />
                </div>
                <div className="flex flex-col space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Preferred Time Range</label>
                  <select className="px-3 py-2.5 text-sm border border-white/10 rounded-xl bg-[#050B16] text-slate-300 focus:outline-none focus:border-[#D4AF37]">
                    <option className="bg-[#050B16] text-slate-200">5:00 PM - 7:00 PM Weekdays</option>
                    <option className="bg-[#050B16] text-slate-200">7:00 PM - 9:00 PM Weekdays</option>
                    <option className="bg-[#050B16] text-slate-200">10:00 AM - 2:00 PM Weekends</option>
                    <option className="bg-[#050B16] text-slate-200">3:00 PM - 6:00 PM Weekends</option>
                  </select>
                </div>
                <button type="submit" className="w-full py-3.5 bg-[#0077FF] hover:bg-[#0066DD] text-white font-bold text-xs uppercase tracking-widest rounded-xl hover:shadow-[0_0_15px_rgba(0,119,255,0.4)] cursor-pointer transition-all">
                  Finalize Free Demo Session
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
