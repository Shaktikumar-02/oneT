import React, { useState } from "react";
import { Sparkles, CheckCircle2, AlertCircle, Loader2, Compass, ShieldAlert } from "lucide-react";

interface LeadFormProps {
  onSuccess?: (leadDetails: any) => void;
  defaultCity?: string;
  compact?: boolean;
}

export default function LeadForm({ onSuccess, defaultCity = "", compact = false }: LeadFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    mobileNumber: "",
    city: defaultCity || "Delhi NCR",
    className: "Class 10",
    subject: "",
    tuitionType: "Home Tuition",
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [submittedLead, setSubmittedLead] = useState<any>(null);

  const majorCities = [
    "Delhi NCR",
    "Mumbai",
    "Bengaluru",
    "Kolkata",
    "Pune",
    "Chennai",
    "Hyderabad",
    "Ahmedabad",
    "Other/Online"
  ];

  const standardClasses = [
    "Class 1 - 5 (Primary)",
    "Class 6 - 8 (Middle)",
    "Class 9",
    "Class 10",
    "Class 11",
    "Class 12",
    "JEE Preparation",
    "NEET Preparation",
    "Computer Coding",
    "Spoken English / Skill",
    "Other Professional Course"
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");

    // Simple robust phone check
    const cleanPhone = formData.mobileNumber.replace(/\D/g, "");
    if (cleanPhone.length < 10) {
      setErrorMsg("Please enter a valid 10-digit mobile number.");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          mobileNumber: formData.mobileNumber,
          city: formData.city,
          class: formData.className,
          subject: formData.subject,
          tuitionType: formData.tuitionType,
        }),
      });

      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || "Something went wrong.");
      }

      setSuccess(true);
      setSubmittedLead(resData.lead);
      if (onSuccess) {
        onSuccess(resData.lead);
      }
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to submit application. Please retry.");
    } finally {
      setLoading(false);
    }
  };

  if (success && submittedLead) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-8 bg-emerald-50/70 border border-emerald-200/50 rounded-2xl animate-fade-in">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 mb-4 ring-8 ring-emerald-50">
          <CheckCircle2 className="h-6 w-6" />
        </div>
        <h3 className="text-lg font-bold text-slate-900">Tuition Request Captured!</h3>
        <p className="text-sm font-medium text-slate-500 mt-2 max-w-sm">
          Thank you, <span className="font-bold text-slate-800">{submittedLead.name}</span>. One of our educational counselors will call you shortly on <span className="font-bold text-slate-800">{submittedLead.mobileNumber}</span> to finalize your premium tutor matching.
        </p>

        <div className="mt-5 w-full bg-white dark:bg-slate-900 border border-slate-100 rounded-xl p-4 text-xs text-left shadow-sm space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-400">Lead Registry ID:</span>
            <span className="font-mono font-semibold text-slate-700 dark:text-slate-350 uppercase">{submittedLead.leadId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Class & Subject:</span>
            <span className="font-semibold text-slate-800 dark:text-white">{submittedLead.class} • {formData.subject}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Tuition Type:</span>
            <span className="font-semibold text-amber-600">{submittedLead.tuitionType}</span>
          </div>
        </div>

        <button
          onClick={() => {
            setSuccess(false);
            setFormData({
              name: "",
              mobileNumber: "",
              city: "Delhi NCR",
              className: "Class 10",
              subject: "",
              tuitionType: "Home Tuition",
            });
          }}
          className="mt-6 px-4 py-2 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-white border border-blue-100 hover:border-blue-200 rounded-lg transition"
        >
          Submit Another Request
        </button>
      </div>
    );
  }

  return (
    <div className={`w-full bg-white/5 border border-white/10 rounded-3xl ${compact ? "p-5" : "p-6 lg:p-8"} shadow-2xl relative overflow-hidden backdrop-blur-xl group`}>
      <div className="absolute inset-0 bg-gradient-to-br from-[#D4AF37]/5 to-transparent opacity-50 -z-10"></div>
      
      {/* Absolute Badge */}
      <div className="absolute -top-3 left-6 flex items-center space-x-1.5 bg-gradient-to-r from-[#D4AF37] to-[#F9E29D] text-[#050B16] text-[11px] font-bold px-3 py-1 rounded-full shadow-[0_0_15px_rgba(212,175,55,0.3)]">
        <Sparkles className="h-3 w-3 animate-pulse text-[#050B16]" />
        <span>Matching Lead Form</span>
      </div>

      <div className="mb-5 mt-2">
        <h4 className="text-lg font-bold text-white font-display">Find Your Ideal Tutor Today</h4>
        <p className="text-xs text-slate-400 font-medium">Verified, background checked, and expert teachers delivered near you.</p>
      </div>

      {errorMsg && (
        <div className="mb-4 flex items-center space-x-2 p-3 text-xs bg-rose-950/40 text-rose-300 rounded-xl border border-rose-900/50">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        
        {/* Name input */}
        <div className="flex flex-col space-y-1">
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Parent / Student Name
          </label>
          <input
            type="text"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="E.g., Anil Kumar"
            className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
          />
        </div>

        {/* Mobile Number Container */}
        <div className="flex flex-col space-y-1">
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Mobile Number (Required)
          </label>
          <div className="relative">
            <span className="absolute left-4 top-2.5 text-sm text-slate-400 font-bold">
              +91
            </span>
            <input
              type="tel"
              required
              maxLength={10}
              value={formData.mobileNumber}
              onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value.replace(/\D/g, "") })}
              placeholder="10-digit mobile phone"
              className="w-full pl-14 pr-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
            />
          </div>
        </div>

        {/* City and Class double column */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col space-y-1">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              City / Location Required
            </label>
            <select
              required
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
            >
              {majorCities.map((city) => (
                <option key={city} value={city} className="bg-[#050B16] text-slate-200">
                  {city}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Grade / Class
            </label>
            <select
              value={formData.className}
              onChange={(e) => setFormData({ ...formData, className: e.target.value })}
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
            >
              {standardClasses.map((cl) => (
                <option key={cl} value={cl} className="bg-[#050B16] text-slate-200">
                  {cl}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Subject required text */}
        <div className="flex flex-col space-y-1">
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Subject Required
          </label>
          <input
            type="text"
            required
            value={formData.subject}
            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
            placeholder="E.g., Calculus Maths, Physics JEE, Spoken English"
            className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
          />
        </div>

        {/* Tuition Mode split check */}
        <div className="flex flex-col space-y-2">
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Preferred Tuition Mode
          </label>
          <div className="grid grid-cols-2 gap-3" id="tuition-type-selectors">
            {["Home Tuition", "Online Tuition"].map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setFormData({ ...formData, tuitionType: mode })}
                className={`py-2 px-3 text-xs font-bold rounded-xl border transition ${
                  formData.tuitionType === mode
                    ? "border-[#D4AF37] bg-white/5 text-[#D4AF37] font-black"
                    : "border-white/10 text-slate-400 bg-[#0A1324] hover:bg-white/5"
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 text-xs font-bold text-white bg-[#0077FF] hover:bg-[#0066DD] hover:shadow-[0_0_20px_rgba(0,119,255,0.4)] rounded-xl transition-all uppercase tracking-widest mt-2 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
          id="find-tutor-now-btn"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin text-white" />
              <span>Registering Lead...</span>
            </>
          ) : (
            <span>Find Tutor Now</span>
          )}
        </button>

        {/* Privacy check warning */}
        <div className="flex items-center space-x-1.5 text-[9px] text-slate-400 justify-center">
          <Compass className="h-3 w-3 text-[#D4AF37]" />
          <span>Verified Secure: HIPAA & SOC2 Compliant Data Safeguard</span>
        </div>

      </form>
    </div>
  );
}
