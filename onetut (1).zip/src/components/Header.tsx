import React, { useState } from "react";
import { Phone, MessageSquare, Shield, Menu, X, Users, Award, Database, Sparkles, Sun, Moon } from "lucide-react";

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
}

export default function Header({ currentTab, setCurrentTab, darkMode, setDarkMode }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "home", label: "Home" },
    { id: "services", label: "Our Services" },
    { id: "subjects", label: "Subjects" },
    { id: "why-us", label: "Why Choose Us" },
    { id: "tutors", label: "Verified Tutors" },
    { id: "ai-match", label: "AI Tutor Match", highlight: true },
    { id: "become-tutor", label: "Become a Tutor" },
    { id: "faq", label: "FAQs" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#050B16]/90 backdrop-blur-md transition-all duration-300">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo Section */}
        <div 
          onClick={() => setCurrentTab("home")} 
          className="flex cursor-pointer items-center space-x-2"
          id="header-logo-container"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-[#D4AF37] to-[#F9E29D] shadow-[0_0_15px_rgba(212,175,55,0.3)]">
            <span className="font-sans text-xl font-black text-[#050B16] tracking-widest">1T</span>
            <div className="absolute -top-1 -right-1 flex h-3 w-3 items-center justify-center rounded-full bg-[#0077FF]">
              <Sparkles className="h-2 w-2 text-white animate-pulse" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold tracking-tight text-white font-display">
              one<span className="text-[#D4AF37]">TUT</span>
            </span>
            <span className="text-[9px] font-semibold tracking-wider text-slate-400 uppercase">
              Tutors • Trust • Excellence
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setCurrentTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`px-3 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
                currentTab === item.id
                  ? item.highlight
                    ? "bg-[#D4AF37] text-[#050B16] font-bold shadow-[0_0_15px_rgba(212,175,55,0.3)]"
                    : "text-[#D4AF37] bg-white/5 border border-white/10"
                  : item.highlight
                  ? "text-[#D4AF37] border border-[#D4AF37]/30 hover:bg-white/5"
                  : "text-slate-300 hover:text-[#D4AF37] hover:bg-white/5"
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Call & Dashboard CTA Actions */}
        <div className="hidden sm:flex items-center space-x-3">
          {/* Dark Mode Indicator (Disabled since sophisticated dark is default) */}
          <div className="flex items-center text-xs text-slate-400 px-2 py-1">
            <span className="h-2 w-2 rounded-full bg-emerald-500 mr-1.5 animate-pulse" />
            <span>Dark active</span>
          </div>

          {/* Verification indicator */}
          <div className="hidden xl:flex items-center space-x-1 text-[11px] font-semibold text-[#D4AF37] bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
            <Shield className="h-3 w-3" />
            <span>ISO Certified</span>
          </div>

          {/* Admin Panel Link */}
          <button
            onClick={() => setCurrentTab("admin")}
            className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition ${
              currentTab === "admin"
                ? "bg-[#D4AF37] border-[#D4AF37] text-[#050B16] font-bold"
                : "border-white/10 bg-white/5 text-slate-200 hover:bg-white/10"
            }`}
            id="admin-dashboard-btn"
          >
            <Database className="h-3.5 w-3.5" />
            <span>CRM Console</span>
          </button>

          {/* Primary CTA Call Now */}
          <a
            href="tel:+917557758503"
            className="flex items-center space-x-1.5 px-4 py-2 text-sm font-bold text-white bg-[#0077FF] hover:bg-[#0066DD] hover:shadow-[0_0_20px_rgba(0,119,255,0.4)] rounded-full transition-all active:scale-95"
            id="header-call-btn"
          >
            <Phone className="h-4 w-4" />
            <span>Call Now</span>
          </a>
        </div>

        {/* Mobile controls */}
        <div className="flex items-center space-x-2 lg:hidden">
          <button
            onClick={() => setCurrentTab("admin")}
            className={`p-2 rounded-xl text-slate-300 hover:bg-white/5 ${currentTab === "admin" ? "text-[#D4AF37]" : ""}`}
            title="CRM Admin"
          >
            <Database className="h-5 w-5" />
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-300 rounded-lg hover:bg-white/5"
            id="mobile-menu-btn"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#050B16] px-4 py-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setCurrentTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`block w-full text-left px-4 py-2.5 text-base font-semibold rounded-lg transition ${
                currentTab === item.id
                  ? "bg-white/5 text-[#D4AF37]"
                  : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{item.label}</span>
                {item.highlight && <Sparkles className="h-4 w-4 text-[#D4AF37]" />}
              </div>
            </button>
          ))}
          <div className="pt-4 border-t border-white/10 flex flex-col space-y-3">
            <a
              href="tel:+917557758503"
              className="flex items-center justify-center space-x-2 w-full py-3 text-center text-sm font-bold text-white bg-[#0077FF] hover:bg-[#0066DD] rounded-xl"
            >
              <Phone className="h-4 w-4" />
              <span>Call Now: +91 7557758503</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
