import React, { useState, useEffect } from "react";
import { Download, Search, RefreshCw, Trash2, Filter, TrendingUp, Users, Award, BookOpen, Clock, Activity, Signal, Eye, Check } from "lucide-react";
import { Lead, Tutor } from "../types";

export default function Dashboard() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [tutors, setTutors] = useState<any[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<"leads" | "tutors" | "insights">("leads");
  
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [cityFilter, setCityFilter] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const loadData = async () => {
    setLoading(true);
    try {
      const lRes = await fetch("/api/leads");
      if (lRes.ok) {
        const lData = await lRes.json();
        setLeads(lData);
      }

      const tRes = await fetch("/api/tutors");
      if (tRes.ok) {
        const tData = await tRes.json();
        setTutors(tData);
      }
    } catch (err) {
      console.error("Error loading CRM Dashboard data: ", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStatusUpdate = async (leadId: string, currentStatus: string) => {
    const statuses = ["New Lead", "In Contact", "Matched", "Converted", "Rejected"];
    const nextIdx = (statuses.indexOf(currentStatus) + 1) % statuses.length;
    const nextStatus = statuses[nextIdx];

    try {
      const response = await fetch(`/api/leads/${leadId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus })
      });

      if (response.ok) {
        setLeads(prev => prev.map(l => l.leadId === leadId ? { ...l, status: nextStatus as any } : l));
      }
    } catch (error) {
      console.error("Error changing lead status:", error);
    }
  };

  const handleDeleteLead = async (leadId: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this lead from records?")) return;

    try {
      const response = await fetch(`/api/leads/${leadId}`, {
        method: "DELETE"
      });

      if (response.ok) {
        setLeads(prev => prev.filter(l => l.leadId !== leadId));
      }
    } catch (error) {
      console.error("Error deleting lead:", error);
    }
  };

  const handleTutorStatusUpdate = async (tutorId: string, currentStatus: string) => {
    const nextStatus = currentStatus === "Pending Review" ? "Approved" : currentStatus === "Approved" ? "Rejected" : "Pending Review";
    try {
      const response = await fetch(`/api/tutors/${tutorId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus })
      });
      if (response.ok) {
        setTutors(prev => prev.map(t => t.tutorId === tutorId ? { ...t, status: nextStatus } : t));
      }
    } catch (err) {
      console.error("Error updating tutor status:", err);
    }
  };

  // Export to CSV Functionality
  const handleExportCSV = () => {
    if (leads.length === 0) {
      alert("No leads found to export.");
      return;
    }

    const headers = ["Lead ID", "Name", "Mobile Number", "City", "Class", "Subject Required", "Tuition Type", "Source", "Status", "Timestamp"];
    const rows = leads.map(l => [
      l.leadId,
      `"${l.name.replace(/"/g, '""')}"`,
      l.mobileNumber,
      `"${l.city.replace(/"/g, '""')}"`,
      `"${l.class.replace(/"/g, '""')}"`,
      `"${l.subject.replace(/"/g, '""')}"`,
      l.tuitionType,
      l.source,
      l.status,
      l.timestamp
    ]);

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `oneTUT_Leads_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filters application
  const filteredLeads = leads.filter(l => {
    const matchesSearch = l.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          l.mobileNumber.includes(searchQuery) ||
                          l.subject.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCity = cityFilter ? l.city === cityFilter : true;
    const matchesSubject = subjectFilter ? l.subject.toLowerCase().includes(subjectFilter.toLowerCase()) : true;
    const matchesStatus = statusFilter ? l.status === statusFilter : true;

    return matchesSearch && matchesCity && matchesSubject && matchesStatus;
  });

  // Insights analytics computations
  const totalLeadsCount = leads.length;
  const newLeadsCount = leads.filter(l => l.status === "New Lead").length;
  const inContactLeadsCount = leads.filter(l => l.status === "In Contact").length;
  const convertedLeadsCount = leads.filter(l => l.status === "Converted").length;

  const homeTuitionCount = leads.filter(l => l.tuitionType === "Home Tuition").length;
  const onlineTuitionCount = leads.filter(l => l.tuitionType === "Online Tuition").length;

  // City based statistics computation
  const cityStats: { [key: string]: number } = {};
  leads.forEach(l => {
    if (l.city) {
      cityStats[l.city] = (cityStats[l.city] || 0) + 1;
    }
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      
      {/* Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-white/10 pb-6 mb-8 gap-4">
        <div>
          <span className="text-xs font-bold text-[#D4AF37] bg-white/5 border border-[#D4AF37]/30 px-2.5 py-1 rounded-full uppercase tracking-wider">
            Enterprise CRM Console
          </span>
          <h2 className="text-2xl font-black text-white mt-2 font-display">oneTUT Lead Management</h2>
          <p className="text-sm font-medium text-slate-400">Review incoming tuition requirements, handle tutor approvals, and assess operational metrics.</p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={loadData}
            disabled={loading}
            className="p-2.5 rounded-xl border border-white/10 text-slate-400 hover:bg-white/5 transition flex items-center justify-center cursor-pointer"
            title="Refresh database"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin text-[#0077FF]" : ""}`} />
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-2 px-4 py-3 bg-[#0077FF] hover:bg-[#0066DD] hover:shadow-[0_0_15px_rgba(0,119,255,0.3)] text-white rounded-xl text-xs font-bold tracking-widest uppercase transition cursor-pointer"
          >
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Numerical Telemetry Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
        
        <div className="bg-white/5 p-4 sm:p-6 rounded-2xl border border-white/10 shadow-xl flex items-center space-x-4">
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-[#0077FF]/10 text-[#0077FF] flex items-center justify-center shrink-0">
            <Users className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Leads</span>
            <h3 className="text-lg sm:text-2xl font-black text-white font-display mt-0.5">{totalLeadsCount}</h3>
          </div>
        </div>

        <div className="bg-white/5 p-4 sm:p-6 rounded-2xl border border-white/10 shadow-xl flex items-center space-x-4">
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
            <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">New Pending</span>
            <h3 className="text-lg sm:text-2xl font-black text-amber-500 font-display mt-0.5">{newLeadsCount}</h3>
          </div>
        </div>

        <div className="bg-white/5 p-4 sm:p-6 rounded-2xl border border-white/10 shadow-xl flex items-center space-x-4">
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
            <Award className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Converted</span>
            <h3 className="text-lg sm:text-2xl font-black text-emerald-400 font-display mt-0.5">{convertedLeadsCount}</h3>
          </div>
        </div>

        <div className="bg-white/5 p-4 sm:p-6 rounded-2xl border border-white/10 shadow-xl flex items-center space-x-4">
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
            <BookOpen className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Tutor Network</span>
            <h3 className="text-lg sm:text-2xl font-black text-indigo-450 font-display mt-0.5">{tutors.length}</h3>
          </div>
        </div>

      </div>

      {/* Tab selection */}
      <div className="flex border-b border-white/10 mb-6">
        <button
          onClick={() => setActiveSubTab("leads")}
          className={`px-5 py-3 text-sm font-semibold border-b-2 transition cursor-pointer ${
            activeSubTab === "leads"
              ? "border-[#D4AF37] text-[#D4AF37] font-bold"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          Parent/Student Leads ({filteredLeads.length})
        </button>

        <button
          onClick={() => setActiveSubTab("tutors")}
          className={`px-5 py-3 text-sm font-semibold border-b-2 transition cursor-pointer ${
            activeSubTab === "tutors"
              ? "border-[#D4AF37] text-[#D4AF37] font-bold"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          Registered Tutor Applicants ({tutors.length})
        </button>

        <button
          onClick={() => setActiveSubTab("insights")}
          className={`px-5 py-3 text-sm font-semibold border-b-2 transition cursor-pointer ${
            activeSubTab === "insights"
              ? "border-[#D4AF37] text-[#D4AF37] font-bold"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          Lead Analytics Pro
        </button>
      </div>

      {/* Tab contents */}
      {activeSubTab === "leads" && (
        <div className="space-y-4">
          {/* Filters shelf */}
          <div className="p-4 bg-white/5 border border-white/10 rounded-2xl grid grid-cols-1 sm:grid-cols-4 gap-4 items-center">
            
            {/* Search inputs */}
            <div className="relative col-span-1 sm:col-span-1">
              <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name, phone, subject..."
                className="w-full pl-9 pr-4 py-2.5 border border-white/10 text-xs rounded-xl bg-[#050B16] focus:outline-none focus:border-[#D4AF37] text-white"
              />
            </div>

            {/* City filter selection */}
            <div>
              <select
                value={cityFilter}
                onChange={(e) => setCityFilter(e.target.value)}
                className="w-full p-2.5 border border-white/10 text-xs rounded-xl bg-[#050B16] focus:outline-none focus:border-[#D4AF37] text-slate-350"
              >
                <option value="" className="bg-[#050B16]">All Cities</option>
                <option value="Delhi NCR" className="bg-[#050B16]">Delhi NCR</option>
                <option value="Mumbai" className="bg-[#050B16]">Mumbai</option>
                <option value="Bengaluru" className="bg-[#050B16]">Bengaluru</option>
                <option value="Kolkata" className="bg-[#050B16]">Kolkata</option>
                <option value="Pune" className="bg-[#050B16]">Pune</option>
                <option value="Chennai" className="bg-[#050B16]">Chennai</option>
                <option value="Hyderabad" className="bg-[#050B16]">Hyderabad</option>
                <option value="Ahmedabad" className="bg-[#050B16]">Ahmedabad</option>
              </select>
            </div>

            {/* Subject input */}
            <div>
              <input
                type="text"
                value={subjectFilter}
                onChange={(e) => setSubjectFilter(e.target.value)}
                placeholder="Filter by Subject"
                className="w-full px-4 py-2.5 border border-white/10 text-xs rounded-xl bg-[#050B16] focus:outline-none focus:border-[#D4AF37] text-white"
              />
            </div>

            {/* Status dropdown filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full p-2.5 border border-white/10 text-xs rounded-xl bg-[#050B16] focus:outline-none focus:border-[#D4AF37] text-slate-350"
              >
                <option value="" className="bg-[#050B16]">All Statuses</option>
                <option value="New Lead" className="bg-[#050B16]">New Lead</option>
                <option value="In Contact" className="bg-[#050B16]">In Contact</option>
                <option value="Matched" className="bg-[#050B16]">Matched</option>
                <option value="Converted" className="bg-[#050B16]">Converted</option>
                <option value="Rejected" className="bg-[#050B16]">Rejected</option>
              </select>
            </div>

          </div>

          {/* Table display */}
          <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
            {filteredLeads.length === 0 ? (
              <div className="p-12 text-center text-slate-400 font-medium">
                No captured leads match the customized search query in database.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-400">
                  <thead className="bg-[#050B16] border-b border-white/10 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <tr>
                      <th className="px-6 py-4">Lead ID & Date</th>
                      <th className="px-6 py-4">Client Contact</th>
                      <th className="px-6 py-4">Target Requirement</th>
                      <th className="px-6 py-4">Mode / Location</th>
                      <th className="px-6 py-4">Lifecycle Status</th>
                      <th className="px-6 py-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredLeads.map((l) => (
                      <tr key={l.leadId} className="hover:bg-white/5 transition">
                        <td className="px-6 py-4">
                          <div className="font-mono text-[11px] font-bold text-slate-300 uppercase">{l.leadId}</div>
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            {new Date(l.timestamp).toLocaleDateString()} at {new Date(l.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-bold text-white capitalize">{l.name}</div>
                          <a href={`tel:${l.mobileNumber}`} className="text-xs text-[#0077FF] hover:underline font-mono">
                            {l.mobileNumber}
                          </a>
                        </td>
                        <td className="px-6 py-4 font-medium">
                          <div className="text-white font-bold">{l.subject}</div>
                          <div className="text-xs text-slate-400">{l.class}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-xs font-bold text-slate-300">{l.tuitionType}</div>
                          <div className="text-[11px] text-slate-500 font-medium whitespace-nowrap">{l.city}</div>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleStatusUpdate(l.leadId, l.status)}
                            className={`px-3 py-1 rounded-full text-xs font-bold hover:brightness-110 active:scale-95 transition cursor-pointer ${
                              l.status === "New Lead"
                                ? "bg-amber-950/40 text-amber-300 border border-amber-900/50"
                                : l.status === "In Contact"
                                ? "bg-[#0077FF]/10 text-[#0077FF] border border-[#0077FF]/25"
                                : l.status === "Matched"
                                ? "bg-indigo-950/40 text-indigo-300 border border-indigo-900/50"
                                : l.status === "Converted"
                                ? "bg-emerald-950/40 text-emerald-300 border border-emerald-900/50"
                                : "bg-rose-950/40 text-rose-300 border border-rose-900/50"
                            }`}
                          >
                            {l.status}
                          </button>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <div className="flex items-center justify-center space-x-2">
                            <button
                              onClick={() => {
                                const details = `Lead Specifications:\nID: ${l.leadId}\nName: ${l.name}\nPhone: ${l.mobileNumber}\nCity: ${l.city}\nClass: ${l.class}\nSubject: ${l.subject}\nStatus: ${l.status}`;
                                alert(details);
                              }}
                              className="p-1 px-3 bg-white/5 hover:bg-white/10 text-xs text-slate-200 font-bold rounded-lg transition border border-white/10 cursor-pointer"
                            >
                              Details
                            </button>
                            <button
                              onClick={() => handleDeleteLead(l.leadId)}
                              className="p-1 text-rose-400 hover:text-rose-500 cursor-pointer"
                              title="Delete Record"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {activeSubTab === "tutors" && (
        <div className="space-y-4">
          <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
            {tutors.length === 0 ? (
              <div className="p-12 text-center text-slate-400 font-medium">
                No tutors registered dynamically through form. Displaying verification queue...
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-400">
                  <thead className="bg-[#050B16] border-b border-white/10 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <tr>
                      <th className="px-6 py-4">Tutor Details</th>
                      <th className="px-6 py-4">Qualification</th>
                      <th className="px-6 py-4">Primary City</th>
                      <th className="px-6 py-4">Expertise / Experience</th>
                      <th className="px-6 py-4">Resume File</th>
                      <th className="px-6 py-4">Status & Approve</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {tutors.map((t, idx) => (
                      <tr key={t.tutorId || idx} className="hover:bg-white/5 transition">
                        <td className="px-6 py-4">
                          <div className="font-bold text-white capitalize">{t.name}</div>
                          <div className="text-xs text-slate-400">{t.email}</div>
                          <div className="text-[11px] font-mono text-slate-500">{t.mobileNumber}</div>
                        </td>
                        <td className="px-6 py-4 text-xs font-semibold max-w-xs truncate text-slate-300">
                          {t.qualification}
                        </td>
                        <td className="px-6 py-4 font-bold text-[#D4AF37]">
                          {t.location || "Delhi NCR"}
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-white font-medium">{t.subjectExpertise}</div>
                          <div className="text-[11px] text-slate-400 font-semibold">{t.experience || "Verified Partner"}</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs italic bg-[#050B16] text-slate-400 px-2.5 py-1 rounded-md border border-white/10">
                            {t.resume || "No uploaded resume"}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleTutorStatusUpdate(t.tutorId, t.status)}
                            className={`px-3 py-1 rounded-full text-xs font-bold hover:brightness-110 active:scale-95 transition cursor-pointer ${
                              t.status === "Approved"
                                ? "bg-emerald-950/40 text-emerald-300 border border-emerald-900/50"
                                : t.status === "Rejected"
                                ? "bg-rose-950/40 text-rose-300 border border-rose-900/50"
                                : "bg-purple-950/40 text-purple-300 border border-purple-900/50"
                            }`}
                          >
                            {t.status || "Approved"}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {activeSubTab === "insights" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Tuition Type Pie Proportion */}
          <div className="bg-white/5 p-6 rounded-3xl border border-white/10 shadow-2xl">
            <h4 className="text-base font-bold text-white font-display mb-4">Tuition Medium Allocation Ratio</h4>
            
            {totalLeadsCount === 0 ? (
              <div className="h-48 flex items-center justify-center text-slate-400 text-xs">No analytics. Capture some leads first.</div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6">
                {/* SVG Donut Circle */}
                <svg className="w-40 h-40" viewBox="0 0 36 36">
                  <path
                    className="text-white/5"
                    strokeWidth="4"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className="text-[#0077FF]"
                    strokeDasharray={`${(homeTuitionCount / totalLeadsCount) * 100}, 100`}
                    strokeWidth="4.2"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>

                <div className="grid grid-cols-2 gap-6 mt-8 w-full border-t border-white/5 pt-4 text-center">
                  <div>
                    <span className="inline-block w-2.5 h-2.5 bg-[#0077FF] rounded-full mr-1.5" />
                    <span className="text-xs font-bold text-slate-450">Home Tuition</span>
                    <h5 className="text-lg font-black text-white mt-1">
                      {homeTuitionCount} ({Math.round((homeTuitionCount / totalLeadsCount) * 100)}%)
                    </h5>
                  </div>
                  <div>
                    <span className="inline-block w-2.5 h-2.5 bg-white/10 rounded-full mr-1.5" />
                    <span className="text-xs font-bold text-slate-450">Online Tuition</span>
                    <h5 className="text-lg font-black text-white mt-1">
                      {onlineTuitionCount} ({Math.round((onlineTuitionCount / totalLeadsCount) * 100)}%)
                    </h5>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Leads by City allocation bar chart */}
          <div className="bg-white/5 p-6 rounded-3xl border border-white/10 shadow-2xl">
            <h4 className="text-base font-bold text-white font-display mb-4">Captured Geo Leads by City Density</h4>

            {Object.keys(cityStats).length === 0 ? (
              <div className="h-48 flex items-center justify-center text-slate-400 text-xs">Awaiting geographical registrations.</div>
            ) : (
              <div className="space-y-4 py-4">
                {Object.entries(cityStats).map(([cityName, count]) => {
                  const percentage = Math.round((count / totalLeadsCount) * 100);
                  return (
                    <div key={cityName} className="space-y-1">
                      <div className="flex justify-between text-xs font-extrabold text-[#D4AF37]">
                        <span className="text-slate-300">{cityName}</span>
                        <span>{count} Leads ({percentage}%)</span>
                      </div>
                      <div className="w-full bg-white/5 rounded-full h-3 overflow-hidden">
                        <div 
                          className="bg-[#D4AF37] h-full rounded-full transition-all duration-350"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
