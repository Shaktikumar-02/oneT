import React from "react";
import { Phone, Mail, MapPin, Sparkles, Shield, BadgeCheck, FileText, Globe } from "lucide-react";

interface FooterProps {
  setCurrentTab: (tab: string) => void;
}

export default function Footer({ setCurrentTab }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const linksSchema = [
    {
      title: "Tuition Services",
      links: [
        { label: "Home Tuition", id: "services" },
        { label: "Online Classes", id: "services" },
        { label: "JEE prep faculty", id: "services" },
        { label: "NEET preparation", id: "services" },
        { label: "Board Exam Special", id: "services" }
      ]
    },
    {
      title: "Popular Subjects",
      links: [
        { label: "Physics & Chemistry", id: "subjects" },
        { label: "Advanced Calculus", id: "subjects" },
        { label: "Computer Coding", id: "subjects" },
        { label: "Spoken English", id: "subjects" },
        { label: "Science foundations", id: "subjects" }
      ]
    },
    {
      title: "Join oneTUT",
      links: [
        { label: "Register as Tutor", id: "become-tutor" },
        { label: "AI Match Demo", id: "ai-match" },
        { label: "Why Parents Trust Us", id: "why-us" },
        { label: "Browse FAQs", id: "faq" },
        { label: "Lead management", id: "admin" }
      ]
    }
  ];

  return (
    <footer className="bg-[#050B16] border-[#D4AF37]/20 border-t text-slate-300 transition-colors">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        
        {/* Top Segment */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 border-b border-slate-800 pb-12">
          
          <div className="lg:col-span-2 flex flex-col space-y-4">
            <div className="flex items-center space-x-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-tr from-[#D4AF37] to-[#F9E29D] shadow-[0_0_10px_rgba(212,175,55,0.2)]">
                <span className="font-sans text-lg font-black text-[#050B16] tracking-widest">1T</span>
              </div>
              <span className="text-xl font-bold tracking-tight text-white font-display">
                one<span className="text-[#D4AF37] font-extrabold">TUT</span>
              </span>
            </div>
            
            <p className="text-sm font-medium text-slate-400 max-w-sm leading-relaxed">
              oneTUT is India's most trusted professional tuition consultancy. We provide personalized home and online teacher matching based on location, class, budget, and custom learning requirements.
            </p>

            <div className="flex flex-col space-y-2.5 pt-2">
              <div className="flex items-center space-x-2.5 text-sm text-slate-300">
                <Phone className="h-4 w-4 text-amber-500" />
                <a href="tel:+917557758503" className="hover:text-white transition">
                  +91 7557758503
                </a>
              </div>
              <div className="flex items-center space-x-2.5 text-sm text-slate-300">
                <Mail className="h-4 w-4 text-amber-500" />
                <a href="mailto:info@onetut.com" className="hover:text-white transition">
                  info@onetut.com
                </a>
              </div>
              <div className="flex items-center space-x-2.5 text-sm text-slate-300">
                <MapPin className="h-4 w-4 text-amber-500" />
                <span>HQ: Sector 5, Salt Lake, Kolkata, West Bengal, India</span>
              </div>
            </div>
          </div>

          {linksSchema.map((group, index) => (
            <div key={index} className="flex flex-col space-y-3.5">
              <h4 className="text-sm font-bold uppercase tracking-wider text-white">
                {group.title}
              </h4>
              <ul className="space-y-2 text-sm">
                {group.links.map((link, lIdx) => (
                  <li key={lIdx}>
                    <button
                      onClick={() => {
                        setCurrentTab(link.id);
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      className="text-slate-400 hover:text-white hover:underline transition text-left"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}

        </div>

        {/* Credentials and safety badges */}
        <div className="my-10 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center sm:text-left bg-white/5 p-6 rounded-2xl border border-white/10">
          <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-3">
            <Shield className="h-8 w-8 text-[#0077FF] shrink-0" />
            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wider">100% Verified Tutors</h5>
              <p className="text-[11px] text-slate-400">ID checked and background screened before assignment.</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-3 border-y sm:border-y-0 sm:border-x border-white/10 py-4 sm:py-0 sm:px-6">
            <BadgeCheck className="h-8 w-8 text-[#D4AF37] shrink-0" />
            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wider">Free Demo Session</h5>
              <p className="text-[11px] text-slate-400">Meet, evaluate, and test the tutor before starting paid plans.</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-3">
            <FileText className="h-8 w-8 text-emerald-500 shrink-0" />
            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wider">Regular Grade Tracking</h5>
              <p className="text-[11px] text-slate-400">Instant monthly progress reports and class telemetry sheets.</p>
            </div>
          </div>
        </div>

        {/* Footer Base */}
        <div className="flex flex-col md:flex-row items-center justify-between text-xs text-slate-500 pt-4">
          <div className="flex items-center space-x-1 mb-2 md:mb-0">
            <span>© {currentYear} oneTUT Consultancy. All rights reserved.</span>
            <span className="text-slate-700">•</span>
            <span>Registered Local Enterprise - Govt. of India</span>
          </div>

          <div className="flex space-x-4">
            <a href="#privacy" className="hover:text-slate-300">Privacy Policy</a>
            <span>•</span>
            <a href="#terms" className="hover:text-slate-300">Terms of Service</a>
            <span>•</span>
            <a href="#sitemap" className="hover:text-slate-300">Sitemap</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
