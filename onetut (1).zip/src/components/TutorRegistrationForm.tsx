import React, { useState } from "react";
import { UploadCloud, CheckCircle, AlertTriangle, Loader2, Sparkles, BookOpen, Star } from "lucide-react";

export default function TutorRegistrationForm() {
  const [formData, setFormData] = useState({
    name: "",
    mobileNumber: "",
    email: "",
    qualification: "",
    experience: "1 - 3 Years",
    subjectExpertise: "",
    location: "Delhi NCR",
    resumeName: "",
  });

  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [registeredId, setRegisteredId] = useState("");

  const experiences = [
    "Fresh Graduate / No prior experience",
    "1 - 3 Years",
    "3 - 5 Years",
    "5 - 10 Years",
    "10+ Years (Senior Faculty)"
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      setUploadProgress(10);
      setFormData(prev => ({ ...prev, resumeName: file.name }));

      // Simulate a beautiful upload progress bar
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            return 100;
          }
          return prev + 15;
        });
      }, 150);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");

    if (cleanPhone(formData.mobileNumber).length < 10) {
      setErrorMsg("Please provide a valid 10-digit mobile number.");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/tutors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          mobileNumber: formData.mobileNumber,
          email: formData.email,
          qualification: formData.qualification,
          experience: formData.experience,
          subjectExpertise: formData.subjectExpertise,
          location: formData.location,
          resume: formData.resumeName || "No Resume PDF uploaded"
        }),
      });

      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || "Tutor registration failed.");
      }

      setSuccess(true);
      setRegisteredId(resData.tutorId);
    } catch (err: any) {
      setErrorMsg(err.message || "Unable to register tutor profile.");
    } finally {
      setLoading(false);
    }
  };

  const cleanPhone = (val: string) => val.replace(/\D/g, "");

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-10 bg-slate-50 dark:bg-slate-900 border border-slate-100 rounded-3xl animate-fade-in shadow-lg">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-200 mb-5 ring-8 ring-blue-50/50">
          <CheckCircle className="h-8 w-8 text-blue-600" />
        </div>
        <h3 className="text-xl font-bold text-slate-900 dark:text-white">Profile Submitted Safely!</h3>
        <p className="text-sm text-slate-500 mt-2 max-w-sm">
          Welcome to the oneTUT tutor network, <span className="font-bold text-slate-800 dark:text-white">{formData.name}</span>. Your application ID is <span className="font-mono font-bold text-amber-600">{registeredId}</span>. 
        </p>
        <p className="text-xs text-slate-400 mt-3 max-w-sm">
          Our internal credential verification team is analyzing your qualification details. We will notify you via Email & WhatsApp once your profile is live for matching with students near you.
        </p>

        <button
          onClick={() => {
            setSuccess(false);
            setFormData({
              name: "",
              mobileNumber: "",
              email: "",
              qualification: "",
              experience: "1 - 3 Years",
              subjectExpertise: "",
              location: "Delhi NCR",
              resumeName: "",
            });
            setUploadProgress(0);
          }}
          className="mt-8 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-md"
        >
          Submit Another Profile
        </button>
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mx-auto bg-white/5 p-6 sm:p-10 border border-white/10 rounded-3xl shadow-2xl relative overflow-hidden backdrop-blur-xl">
      <div className="absolute inset-0 bg-gradient-to-br from-[#D4AF37]/5 to-transparent opacity-50 -z-10" />
      <div className="flex items-center space-x-2 text-[#D4AF37] font-bold text-xs uppercase tracking-widest mb-2">
        <Sparkles className="h-4 w-4 animate-pulse text-[#D4AF37]" />
        <span>Tutor Registry Panel</span>
      </div>
      <h3 className="text-2xl font-bold tracking-tight text-white font-display">Become a Certified oneTUT Educator</h3>
      <p className="text-sm font-medium text-slate-400 mt-1 mb-8">
        Gain access to hundreds of verified student leads looking for high-quality home tuition & online coaching in your specialty subject.
      </p>

      {errorMsg && (
        <div className="mb-6 flex items-center space-x-2 p-4 text-sm bg-rose-950/40 text-rose-300 rounded-xl border border-rose-900/50">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleRegister} className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Name */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Full Name
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Prof. / Dr. / Mr. / Ms."
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
            />
          </div>

          {/* Mobile phone */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Mobile Contact Number
            </label>
            <input
              type="tel"
              required
              maxLength={10}
              value={formData.mobileNumber}
              onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value.replace(/\D/g, "") })}
              placeholder="10-digit mobile number"
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Email */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Email Address
            </label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="name@example.com"
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
            />
          </div>

          {/* Location */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Your Primary City
            </label>
            <select
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
            >
              <option value="Delhi NCR" className="bg-[#050B16] text-slate-200">Delhi NCR</option>
              <option value="Mumbai" className="bg-[#050B16] text-slate-200">Mumbai</option>
              <option value="Bengaluru" className="bg-[#050B16] text-slate-200">Bengaluru</option>
              <option value="Kolkata" className="bg-[#050B16] text-slate-200">Kolkata</option>
              <option value="Pune" className="bg-[#050B16] text-slate-200">Pune</option>
              <option value="Chennai" className="bg-[#050B16] text-slate-200">Chennai</option>
              <option value="Hyderabad" className="bg-[#050B16] text-slate-200">Hyderabad</option>
              <option value="Ahmedabad" className="bg-[#050B16] text-slate-200">Ahmedabad</option>
            </select>
          </div>
        </div>

        {/* Qualification */}
        <div className="flex flex-col space-y-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Educational Qualification
          </label>
          <input
            type="text"
            required
            value={formData.qualification}
            onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
            placeholder="E.g., M.Sc. in Mathematics (DU), JEE Rank 350, PhD in chemistry"
            className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Experience level */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Teaching Experience
            </label>
            <select
              value={formData.experience}
              onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] text-slate-300 focus:outline-none focus:border-[#D4AF37] transition"
            >
              {experiences.map((exp) => (
                <option key={exp} value={exp} className="bg-[#050B16] text-slate-200">
                  {exp}
                </option>
              ))}
            </select>
          </div>

          {/* Subject Expertise */}
          <div className="flex flex-col space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Core Subject Expertise
            </label>
            <input
              type="text"
              required
              value={formData.subjectExpertise}
              onChange={(e) => setFormData({ ...formData, subjectExpertise: e.target.value })}
              placeholder="Physics, Advanced Math, Python Coding, spoken english"
              className="w-full px-4 py-2.5 text-sm border border-white/10 rounded-xl bg-[#0A1324] focus:outline-none focus:border-[#D4AF37] text-slate-200 transition"
            />
          </div>
        </div>

        {/* Resume PDF File uploader */}
        <div className="flex flex-col space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Professional Resume Upload (.pdf or .docx)
          </label>
          <div className="border-2 border-dashed border-white/10 rounded-2xl p-6 text-center hover:bg-white/5 transition duration-200 relative">
            <input
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <div className="flex flex-col items-center justify-center space-y-1">
              <UploadCloud className="h-10 w-10 text-slate-500 mb-1" />
              <p className="text-sm font-bold text-slate-300">
                {formData.resumeName ? formData.resumeName : "Drag & drop files or click to choose"}
              </p>
              <p className="text-xs text-slate-500">Supports PDF, DOCX up to 15MB file size.</p>
            </div>

            {/* Custom interactive loading percentage bar */}
            {isUploading && (
              <div className="mt-4 w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                <div 
                  className="bg-[#0077FF] h-full rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            )}
            {uploadProgress === 100 && (
              <div className="mt-2 text-xs font-semibold text-emerald-400 flex items-center justify-center space-x-1 animate-pulse">
                <Star className="h-3.5 w-3.5 text-[#D4AF37] fill-[#D4AF37]" />
                <span>Resume parsed successfully. Attachment established!</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Button */}
        <button
          type="submit"
          disabled={loading || isUploading}
          className="w-full py-4 text-sm font-bold text-white bg-[#0077FF] hover:bg-[#0066DD] hover:shadow-[0_0_20px_rgba(0,119,255,0.4)] disabled:opacity-50 active:scale-95 transition-all shadow-md rounded-2xl flex items-center justify-center space-x-2 cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Verifying Qualifications...</span>
            </>
          ) : (
            <span>Submit Teacher Application</span>
          )}
        </button>

      </form>
    </div>
  );
}
