import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, getDocs, doc, updateDoc, deleteDoc, query, where, getDoc } from "firebase/firestore";

// Read Firebase configuration
const configPath = path.join(process.cwd(), "firebase-applet-config.json");
let firebaseConfig: any = {};
if (fs.existsSync(configPath)) {
  firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf8"));
}

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);

const app = express();
app.use(express.json());
const PORT = 3000;

// Lazy initialize Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn("GEMINI_API_KEY is not defined in the environment variables.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key || "MOCK_KEY_IF_ABSENT",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Standard Mock Tutors list to seed or fall back to
const MOCK_TUTORS_POOL = [
  {
    tutorId: "tut_01",
    name: "Dr. Rajesh Mukhopadhyay",
    mobileNumber: "+91 9876543210",
    email: "rajesh.m@onetut.com",
    qualification: "Ph.D. in Physics (IIT Kharagpur)",
    experience: "12+ Years",
    subjectExpertise: "JEE Physics, CBSE Chemistry, NEET Physics",
    location: "Kolkata",
    rating: 4.9,
    reviewsCount: 142,
    starred: true,
    bio: "Ex-FIITJEE senior faculty specializing in mechanics & electromagnetism. Achieved 98% success rate in JEE Advanced mentoring.",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
    tuitionType: "Both",
    hourlyRate: "₹800 - ₹1200"
  },
  {
    tutorId: "tut_02",
    name: "Mrs. Shreya Iyer",
    mobileNumber: "+91 8765432109",
    email: "shreya.iyer@onetut.com",
    qualification: "M.Sc. in Mathematics (Delhi University)",
    experience: "8 Years",
    subjectExpertise: "Mathematics (Class 9-12), Calculus, Calculus & Algebra",
    location: "Delhi NCR",
    rating: 4.8,
    reviewsCount: 98,
    starred: true,
    bio: "Passionate educator focused on conceptual understanding of Calculus and Coordinate Geometry. Patient with slow learners.",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    tuitionType: "Online Tuition",
    hourlyRate: "₹600 - ₹900"
  },
  {
    tutorId: "tut_03",
    name: "Prof. Amit Verma",
    mobileNumber: "+91 7654321098",
    email: "amit.verma@onetut.com",
    qualification: "M.Tech in Computer Science (BITS Pilani)",
    experience: "10+ Years",
    subjectExpertise: "Coding, Computer Science, Python, Programming, Artificial Intelligence",
    location: "Bengaluru",
    rating: 4.9,
    reviewsCount: 115,
    starred: true,
    bio: "Senior software consultant. Teaches full-stack development, Python programming, and AI foundational concepts to students.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    tuitionType: "Both",
    hourlyRate: "₹900 - ₹1500"
  },
  {
    tutorId: "tut_04",
    name: "Dr. Anjali Deshmukh",
    mobileNumber: "+91 6543210987",
    email: "anjali.d@onetut.com",
    qualification: "MD in Physiology, M.Sc. Biology",
    experience: "15 Years",
    subjectExpertise: "NEET Biology, Zoology, Botany, Science (Class 9-10)",
    location: "Mumbai",
    rating: 5.0,
    reviewsCount: 184,
    starred: true,
    bio: "Specializes in NEET Medical Preparation. Known for high-scoring biology notes, interactive diagrammatic sessions, and high success rates.",
    avatar: "https://images.unsplash.com/photo-1594744803329-e58b31de215f?auto=format&fit=crop&q=80&w=200",
    tuitionType: "Home Tuition",
    hourlyRate: "₹1000 - ₹1500"
  },
  {
    tutorId: "tut_05",
    name: "Mr. Rohan Saxena",
    mobileNumber: "+91 9123456789",
    email: "rohan.saxena@onetut.com",
    qualification: "MA in English Literature",
    experience: "6 Years",
    subjectExpertise: "English, Spoken English, Hindi, Social Science",
    location: "Pune",
    rating: 4.7,
    reviewsCount: 64,
    starred: false,
    bio: "Focuses on English phonetics, communication strategies, interview preparation, and CBSE/ICSE literature syllabus coverage.",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200",
    tuitionType: "Both",
    hourlyRate: "₹500 - ₹700"
  },
  {
    tutorId: "tut_06",
    name: "CA Manoj Gupta",
    mobileNumber: "+91 9234567890",
    email: "manoj.g@onetut.com",
    qualification: "Chartered Accountant, B.Com",
    experience: "9 Years",
    subjectExpertise: "Accountancy, Economics, Business Studies",
    location: "Delhi NCR",
    rating: 4.9,
    reviewsCount: 82,
    starred: true,
    bio: "Practicing CA with a drive to teach commerce. Simplifies double-entry bookkeeping, corporate taxation, and macroeconomic graphs.",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200",
    tuitionType: "Home Tuition",
    hourlyRate: "₹800 - ₹1200"
  }
];

// Helper to get all combined tutors (Mock + Submissions from Firestore)
async function getFullTutorsList() {
  try {
    const listSnapshot = await getDocs(collection(db, "tutors"));
    const dbTutorsList: any[] = [];
    listSnapshot.forEach((docSnap) => {
      dbTutorsList.push({ id: docSnap.id, ...docSnap.data() });
    });

    // Merge mock and DB tutors
    const mappedDbTutors = dbTutorsList.map((t) => ({
      tutorId: t.tutorId || t.id,
      name: t.name,
      mobileNumber: t.mobileNumber,
      email: t.email,
      qualification: t.qualification,
      experience: t.experience || "Fresh Entry",
      subjectExpertise: t.subjectExpertise,
      location: t.location || "Delhi NCR",
      rating: 4.5,
      reviewsCount: 1,
      starred: false,
      bio: "Registered teacher looking for students.",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
      tuitionType: "Both",
      hourlyRate: "Custom"
    }));

    return [...MOCK_TUTORS_POOL, ...mappedDbTutors];
  } catch (err) {
    console.warn("Could not read tutors from Firestore, returning mock data:", err);
    return MOCK_TUTORS_POOL;
  }
}

// 1. Get List of Leads
app.get("/api/leads", async (req, res) => {
  try {
    const { city, subject, status } = req.query;
    const leadsSnapshot = await getDocs(collection(db, "leads"));
    let leads: any[] = [];
    leadsSnapshot.forEach((docSnap) => {
      leads.push({ id: docSnap.id, ...docSnap.data() });
    });

    // Apply basic filtering in memory for safety
    if (city) {
      leads = leads.filter(l => l.city && l.city.toLowerCase().includes((city as string).toLowerCase()));
    }
    if (subject) {
      leads = leads.filter(l => l.subject && l.subject.toLowerCase().includes((subject as string).toLowerCase()));
    }
    if (status) {
      leads = leads.filter(l => l.status === status);
    }

    // Sort by timestamp desc
    leads.sort((a, b) => {
      return new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime();
    });

    res.json(leads);
  } catch (error) {
    console.error("Error retrieving leads from Firestore: ", error);
    res.status(500).json({ error: "Failed to load leads from database." });
  }
});

// 2. Submit a new lead
app.post("/api/leads", async (req, res) => {
  try {
    const { name, mobileNumber, city, class: studentClass, subject, tuitionType } = req.body;
    
    if (!name || !mobileNumber || !city || !subject || !tuitionType) {
      return res.status(400).json({ error: "Required fields are missing." });
    }

    const leadId = "lead_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    const newLead = {
      leadId,
      name,
      mobileNumber,
      city,
      class: studentClass || "",
      subject,
      tuitionType,
      timestamp: new Date().toISOString(),
      source: "Website",
      status: "New Lead"
    };

    const docRef = await addDoc(collection(db, "leads"), newLead);
    res.status(201).json({ success: true, leadId, id: docRef.id, lead: newLead });
  } catch (error) {
    console.error("Error creating lead in Firestore: ", error);
    res.status(500).json({ error: "Failed to capture lead. Please try again." });
  }
});

// 3. Update Lead Status
app.put("/api/leads/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ error: "Status field is required." });
    }

    const q = query(collection(db, "leads"), where("leadId", "==", id));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      return res.status(404).json({ error: "Lead not found." });
    }

    const docId = querySnapshot.docs[0].id;
    await updateDoc(doc(db, "leads", docId), { status });

    res.json({ success: true, id, status });
  } catch (error) {
    console.error("Error updating lead status in Firestore: ", error);
    res.status(500).json({ error: "Failed to update lead status." });
  }
});

// 4. Delete Lead
app.delete("/api/leads/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const q = query(collection(db, "leads"), where("leadId", "==", id));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      return res.status(404).json({ error: "Lead not found." });
    }

    const docId = querySnapshot.docs[0].id;
    await deleteDoc(doc(db, "leads", docId));

    res.json({ success: true, message: `Lead ${id} deleted successfully.` });
  } catch (error) {
    console.error("Error deleting lead from Firestore: ", error);
    res.status(500).json({ error: "Failed to delete lead." });
  }
});

// 5. Submit tutor registration
app.post("/api/tutors", async (req, res) => {
  try {
    const { name, mobileNumber, email, qualification, experience, subjectExpertise, resume, location } = req.body;

    if (!name || !mobileNumber || !email || !qualification || !experience || !subjectExpertise) {
      return res.status(400).json({ error: "Required tutor registration fields are missing." });
    }

    const tutorId = "tut_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    const newTutor = {
      tutorId,
      name,
      mobileNumber,
      email,
      qualification,
      experience,
      subjectExpertise,
      location: location || "Delhi NCR",
      resume: resume || "No resume uploaded",
      timestamp: new Date().toISOString(),
      status: "Pending Review"
    };

    const docRef = await addDoc(collection(db, "tutors"), newTutor);
    res.status(201).json({ success: true, tutorId, id: docRef.id, tutor: newTutor });
  } catch (error) {
    console.error("Error registering tutor in Firestore: ", error);
    res.status(500).json({ error: "Failed to submit tutor application." });
  }
});

// 6. Get Tutors List (Includes both mock pool + dynamic entries)
app.get("/api/tutors", async (req, res) => {
  try {
    const list = await getFullTutorsList();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to get tutors list." });
  }
});

// 7. Update Tutor Status
app.put("/api/tutors/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ error: "Status field is required." });
    }

    const q = query(collection(db, "tutors"), where("tutorId", "==", id));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      // If it's a mock tutor, we can simulate updating its status or report success
      return res.json({ success: true, id, status, message: "Mock tutor state updated" });
    }

    const docId = querySnapshot.docs[0].id;
    await updateDoc(doc(db, "tutors", docId), { status });

    res.json({ success: true, id, status });
  } catch (error) {
    console.error("Error updating tutor status: ", error);
    res.status(500).json({ error: "Failed to update tutor status." });
  }
});

// 8. AI-Powered Tutor Matching
app.post("/api/ai/match", async (req, res) => {
  try {
    const { className, subject, city, tuitionType, requirements } = req.body;

    if (!subject || !city) {
      return res.status(400).json({ error: "Subject and City are required to match tutors." });
    }

    const tutorsList = await getFullTutorsList();

    // Prepare prompt for Gemini AI
    const prompt = `
You are the Chief Tutor Matching AI for "oneTUT", India's most trusted home tutor consultancy.
We have received a tuition requirement from a student/parent:
- Student Grade/Class: ${className || "Not specified"}
- Subject Needed: ${subject}
- Preferred City: ${city}
- Tuition Type: ${tuitionType || "Any"}
- Special Requirements / Learning Goals: ${requirements || "Help with fundamentals and regular homework."}

Here are the profiles of verified tutors currently available in our system:
${JSON.stringify(tutorsList, null, 2)}

Your task is to analyze these tutor profiles and output the top 3 best matching tutors in a rigorous JSON format.
You must return a JSON array containing objects with the following schema:
- tutorId: (The tutor's identifier string from the profiles)
- matchPercentage: (An integer representing the quality of match, from 0 to 100)
- fitAnalysis: (A concise 1-2 sentence description explaining exactly why this tutor's qualification and experience is a perfect fit for this student's grade/goals).
- recommendations: (A short bullet list of 2 specific tutoring strategies this tutor can apply based on their background and student's requirements).

Ensure the response is raw JSON only, matching the exact format schema. DO NOT wrap in Markdown code blocks (no \`\`\`json or similar). Do not write explaining text outside of JSON.
`;

    const instructions = "You are a professional educational planner matching students with tutors. You output only valid JSON.";

    const gemini = getGeminiClient();
    const response = await gemini.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: instructions,
        responseMimeType: "application/json",
        temperature: 0.2,
      }
    });

    const resultText = response.text || "[]";
    let matchedData = [];
    try {
      matchedData = JSON.parse(resultText.trim());
    } catch (parseErr) {
      console.warn("Could not parse JSON cleanly from Gemini, extracting using fallback regex.", parseErr);
      const cleanJsonStr = resultText.replace(/```json/g, "").replace(/```/g, "").trim();
      matchedData = JSON.parse(cleanJsonStr);
    }

    // Combine matching analysis with full tutor stats
    const enrichedMatching = matchedData.map((match: any) => {
      const originalTutorObj = tutorsList.find(t => t.tutorId === match.tutorId);
      return {
        ...match,
        tutorInfo: originalTutorObj || {
          name: "Expert Tutor Match",
          qualification: "Verified Professional Teacher",
          experience: "5+ Years",
          subjectExpertise: subject,
          location: city,
          rating: 4.8,
          avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
          hourlyRate: "Competitive"
        }
      };
    });

    res.json({
      success: true,
      requirements: { className, subject, city, tuitionType, requirements },
      matches: enrichedMatching
    });

  } catch (error: any) {
    console.error("Gemini Tutor Matching Error: ", error);
    res.status(500).json({ error: "AI tutor matching failed. Please try manual matching or retry." });
  }
});

// Setup Vite Dev server or Serve static files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[oneTUT server] running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
